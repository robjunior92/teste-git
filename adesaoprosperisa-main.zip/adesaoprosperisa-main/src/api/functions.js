import { base44 } from './base44Client';


export const generatePDF = base44.functions.generatePDF;

export const sendSMSVerification = base44.functions.sendSMSVerification;

export const validateSMSCode = base44.functions.validateSMSCode;

export const sendEmailVerification = base44.functions.sendEmailVerification;

export const validateEmailCode = base44.functions.validateEmailCode;

export const uploadDocumentToOneDrive = base44.functions.uploadDocumentToOneDrive;

