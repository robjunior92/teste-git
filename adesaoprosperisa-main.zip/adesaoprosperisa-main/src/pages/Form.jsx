
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import Step1Identificacao from "../components/form/Step1Identificacao";
import Step2MeusDados from "../components/form/Step2MeusDados";
import Step3Investimento from "../components/form/Step3Investimento";
import Step4Servicos from "../components/form/Step4Servicos";
import Step5Confirmacao from "../components/form/Step5Confirmacao";
import SuccessScreen from "../components/form/SuccessScreen";
import ProgressBar from "../components/form/ProgressBar";

export default function FormPage() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    // Etapa 1
    nome_completo: "",
    cpf: "",
    celular: "",
    email: "",
    aceite_privacidade: false,
    
    // Etapa 2
    data_nascimento: "",
    sexo: "",
    estado_civil: "",
    endereco: {
      cep: "",
      logradouro: "",
      numero: "",
      bairro: "",
      complemento: "",
      municipio: "",
      uf: ""
    },
    // Adicionado para upload de documentos
    documentos: {
      rg_url: null,
      cin_url: null,
      cnh_url: null
    },
    
    // Etapa 3
    tempo_investimento_anos: 1,
    valor_objetivo: 0,
    valor_mensal: 0,
    dia_vencimento: 5,
    responsavel_financeiro: true,
    responsavel_nome: "",
    responsavel_cpf: "",
    forma_pagamento: "PIX",
    
    // Etapa 4
    servico_funeral: false,
    servico_pet: false,
    
    // Etapa 5
    aceite_termos: false,
    aceite_veracidade: false
  });
  
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const updateFormData = (data) => {
    setFormData(prev => ({ ...prev, ...data }));
  };

  const nextStep = () => {
    if (currentStep < 5) {
      setCurrentStep(currentStep + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleCancel = () => {
    if (window.confirm("Tem certeza que deseja cancelar? Todos os dados serão perdidos.")) {
      setFormData({
        nome_completo: "",
        cpf: "",
        celular: "",
        email: "",
        aceite_privacidade: false,
        data_nascimento: "",
        sexo: "",
        estado_civil: "",
        endereco: {
          cep: "",
          logradouro: "",
          numero: "",
          bairro: "",
          complemento: "",
          municipio: "",
          uf: ""
        },
        documentos: { // Resetar os documentos também
          rg_url: null,
          cin_url: null,
          cnh_url: null
        },
        tempo_investimento_anos: 1,
        valor_objetivo: 0,
        valor_mensal: 0,
        dia_vencimento: 5,
        responsavel_financeiro: true,
        responsavel_nome: "",
        responsavel_cpf: "",
        forma_pagamento: "PIX",
        servico_funeral: false,
        servico_pet: false,
        aceite_termos: false,
        aceite_veracidade: false
      });
      setCurrentStep(1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    try {
      // Criar hash simples do CPF (em produção, isso deve ser feito no backend)
      const cpfHash = btoa(formData.cpf);
      
      // Verificar duplicidade
      const existing = await base44.entities.Registration.filter({ cpf_hash: cpfHash });
      
      if (existing && existing.length > 0) {
        alert("O CPF informado já consta em nosso sistema. Se você acredita que é um erro, entre em contato com o suporte.");
        setIsSubmitting(false);
        return;
      }
      
      // Calcular valor total dos serviços
      const valorServicos = (formData.servico_funeral ? 25 : 0) + (formData.servico_pet ? 10 : 0);
      
      // Preparar payload para webhook no formato correto
      const webhookPayload = {
        source: "prosperisa-web",
        submittedAt: new Date().toISOString(),
        nomeCompleto: formData.nome_completo,
        cpf: formData.cpf,
        celular: formData.celular,
        email: formData.email,
        dataNascimento: formData.data_nascimento,
        sexo: formData.sexo.toLowerCase(),
        estadoCivil: formData.estado_civil.toLowerCase(),
        enderecoCompleto: {
          cep: formData.endereco.cep,
          logradouro: formData.endereco.logradouro,
          numero: formData.endereco.numero,
          bairro: formData.endereco.bairro,
          complemento: formData.endereco.complemento || "",
          municipio: formData.endereco.municipio,
          uf: formData.endereco.uf
        },
        documentos: formData.documentos, // Incluir documentos no payload do webhook
        tempoEmAnos: formData.tempo_investimento_anos,
        valorObjetivo: formData.valor_objetivo,
        valorMensalDefinido: formData.valor_mensal,
        diaVencimento: formData.dia_vencimento,
        responsavelFinanceiro: formData.responsavel_financeiro,
        formaPagamento: formData.forma_pagamento,
        servicosAdicionais: {
          funeralCapitalizacao: formData.servico_funeral,
          seguroPet: formData.servico_pet,
          valorTotal: valorServicos
        },
        aceitePrivacidade: formData.aceite_privacidade,
        aceiteTermos: formData.aceite_termos
      };
      
      // Salvar no banco de dados
      await base44.entities.Registration.create({
        cpf_hash: cpfHash,
        nome_completo: formData.nome_completo,
        cpf: formData.cpf,
        celular: formData.celular,
        email: formData.email,
        data_nascimento: formData.data_nascimento,
        sexo: formData.sexo,
        estado_civil: formData.estado_civil,
        endereco: formData.endereco,
        documentos: formData.documentos, // Incluir documentos na base de dados
        tempo_investimento_anos: formData.tempo_investimento_anos,
        valor_objetivo: formData.valor_objetivo,
        valor_mensal: formData.valor_mensal,
        dia_vencimento: formData.dia_vencimento,
        responsavel_financeiro: formData.responsavel_financeiro,
        responsavel_nome: formData.responsavel_nome,
        responsavel_cpf: formData.responsavel_cpf,
        forma_pagamento: formData.forma_pagamento,
        servico_funeral: formData.servico_funeral,
        servico_pet: formData.servico_pet,
        aceite_privacidade: formData.aceite_privacidade,
        aceite_termos: formData.aceite_termos,
        webhook_enviado: false,
        status: "Pendente"
      });
      
      // Enviar para webhook
      try {
        await fetch("https://cbautomacaoeai.app.n8n.cloud/webhook/fluxoform", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(webhookPayload)
        });
      } catch (webhookError) {
        console.error("Erro ao enviar webhook:", webhookError);
      }
      
      setIsSubmitted(true);
    } catch (error) {
      console.error("Erro ao submeter formulário:", error);
      alert("Ocorreu um erro ao processar seu cadastro. Por favor, tente novamente.");
    }
    
    setIsSubmitting(false);
  };

  if (isSubmitted) {
    return <SuccessScreen />;
  }

  return (
    <div className="min-h-screen bg-[#FAFAF9] py-8">
      <div className="max-w-4xl mx-auto px-6">
        <ProgressBar currentStep={currentStep} />
        
        <div className="bg-white rounded-lg shadow-lg p-8 mt-8">
          {currentStep === 1 && (
            <Step1Identificacao
              formData={formData}
              updateFormData={updateFormData}
              onNext={nextStep}
              onCancel={handleCancel}
            />
          )}
          
          {currentStep === 2 && (
            <Step2MeusDados
              formData={formData}
              updateFormData={updateFormData}
              onNext={nextStep}
              onPrev={prevStep}
              onCancel={handleCancel}
            />
          )}
          
          {currentStep === 3 && (
            <Step3Investimento
              formData={formData}
              updateFormData={updateFormData}
              onNext={nextStep}
              onPrev={prevStep}
              onCancel={handleCancel}
            />
          )}
          
          {currentStep === 4 && (
            <Step4Servicos
              formData={formData}
              updateFormData={updateFormData}
              onNext={nextStep}
              onPrev={prevStep}
              onCancel={handleCancel}
            />
          )}
          
          {currentStep === 5 && (
            <Step5Confirmacao
              formData={formData}
              updateFormData={updateFormData}
              onPrev={prevStep}
              onCancel={handleCancel}
              onSubmit={handleSubmit}
              isSubmitting={isSubmitting}
            />
          )}
        </div>
      </div>
    </div>
  );
}
