//Comentário Teste
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Search, Eye, Download, FileText, DollarSign, Shield, Printer } from "lucide-react";
import ReactDOM from "react-dom/client";
import PrintView from "../components/admin/PrintView";

export default function AdminPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRegistrations, setSelectedRegistrations] = useState([]);
  const [detailsRegistration, setDetailsRegistration] = useState(null);
  const [exportFields, setExportFields] = useState({
    // Identificação
    identificacao: true,
    identificacao_nome: true,
    identificacao_email: true,
    identificacao_celular: true,
    
    // Dados Pessoais
    dados_pessoais: true,
    dados_pessoais_nascimento: true,
    dados_pessoais_sexo: true,
    dados_pessoais_estado_civil: true,
    
    // Endereço
    endereco: true,
    endereco_completo: true,
    
    // Investimento
    investimento: true,
    investimento_tempo: true,
    investimento_valor_objetivo: true,
    investimento_valor_mensal: true,
    investimento_vencimento: true,
    investimento_responsavel: true,
    investimento_forma_pagamento: true,
    
    // Serviços
    servicos: true,
    servicos_funeral: true,
    servicos_pet: true,
    
    // Sistema
    sistema_ip: false,
    sistema_data_cadastro: true,
  });
  const [showExportDialog, setShowExportDialog] = useState(false);

  const { data: registrations, isLoading } = useQuery({
    queryKey: ['registrations'],
    queryFn: () => base44.entities.Registration.list("-created_date"),
    initialData: [],
  });

  const filteredRegistrations = registrations.filter(reg => {
    const searchLower = searchTerm.toLowerCase();
    return (
      reg.nome_completo?.toLowerCase().includes(searchLower) ||
      reg.email?.toLowerCase().includes(searchLower) ||
      reg.celular?.includes(searchTerm)
    );
  });

  const getTotalValue = () => {
    return registrations.reduce((sum, reg) => {
      let total = reg.valor_mensal || 0;
      if (reg.servico_funeral) total += 25;
      if (reg.servico_pet) total += 10;
      return sum + total;
    }, 0);
  };

  const getServicesCount = (serviceType) => {
    return registrations.filter(reg => reg[serviceType]).length;
  };

  const toggleRegistrationSelection = (id) => {
    setSelectedRegistrations(prev =>
      prev.includes(id) ? prev.filter(regId => regId !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    if (selectedRegistrations.length === filteredRegistrations.length && filteredRegistrations.length > 0) {
      setSelectedRegistrations([]);
    } else {
      setSelectedRegistrations(filteredRegistrations.map(reg => reg.id));
    }
  };

  const toggleAllInSection = (section) => {
    const sectionFields = Object.keys(exportFields).filter(key => key.startsWith(section + '_') || key === section);
    const allChecked = sectionFields.every(field => exportFields[field]);
    
    const newFields = { ...exportFields };
    sectionFields.forEach(field => {
      newFields[field] = !allChecked;
    });
    setExportFields(newFields);
  };

  const selectAllFields = () => {
    const allSelected = Object.values(exportFields).every(v => v);
    const newFields = {};
    Object.keys(exportFields).forEach(key => {
      newFields[key] = !allSelected;
    });
    setExportFields(newFields);
  };

  const deselectAllFields = () => {
    const newFields = {};
    Object.keys(exportFields).forEach(key => {
      newFields[key] = false;
    });
    setExportFields(newFields);
  };

  const getSelectedFieldsCount = () => {
    return Object.values(exportFields).filter(v => v).length;
  };

  const handlePrintSelected = () => {
    if (selectedRegistrations.length === 0) {
      alert("Selecione pelo menos um cadastro para exportar");
      return;
    }

    const selectedRegs = registrations.filter(reg => selectedRegistrations.includes(reg.id));
    
    // Criar nova janela para impressão
    const printWindow = window.open('', '_blank');
    printWindow.document.write('<html><head><title>Prosperisa+ - Cadastros</title>');
    printWindow.document.write('<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">');
    printWindow.document.write('</head><body>');
    printWindow.document.write('<div id="print-root"></div>');
    printWindow.document.write('</body></html>');
    printWindow.document.close();

    // Renderizar o componente React na nova janela
    setTimeout(() => {
      const root = ReactDOM.createRoot(printWindow.document.getElementById('print-root'));
      root.render(<PrintView registrations={selectedRegs} fields={exportFields} />);
      
      // Aguardar renderização e abrir diálogo de impressão
      setTimeout(() => {
        printWindow.print();
      }, 500);
    }, 100);

    setShowExportDialog(false);
  };

  const handlePrintSingle = (registration) => {
    const printWindow = window.open('', '_blank');
    printWindow.document.write('<html><head><title>Prosperisa+ - Cadastro</title>');
    printWindow.document.write('<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">');
    printWindow.document.write('</head><body>');
    printWindow.document.write('<div id="print-root"></div>');
    printWindow.document.write('</body></html>');
    printWindow.document.close();

    setTimeout(() => {
      const root = ReactDOM.createRoot(printWindow.document.getElementById('print-root'));
      root.render(<PrintView 
        registrations={[registration]} 
        fields={{
          identificacao: true,
          identificacao_nome: true,
          identificacao_email: true,
          identificacao_celular: true,
          dados_pessoais: true,
          dados_pessoais_nascimento: true,
          dados_pessoais_sexo: true,
          dados_pessoais_estado_civil: true,
          endereco: true,
          endereco_completo: true,
          investimento: true,
          investimento_tempo: true,
          investimento_valor_objetivo: true,
          investimento_valor_mensal: true,
          investimento_vencimento: true,
          investimento_responsavel: true,
          investimento_forma_pagamento: true,
          servicos: true,
          servicos_funeral: true,
          servicos_pet: true,
          sistema_data_cadastro: true,
        }} 
      />);
      
      setTimeout(() => {
        printWindow.print();
      }, 500);
    }, 100);
  };

  return (
    <div className="min-h-screen bg-[#FAFAF9] py-8">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="w-16 h-16 rounded-full bg-[#6FCF97] flex items-center justify-center">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-[#27AE60]">Painel Administrativo</h1>
            <p className="text-[#4F4F4F]">Gerenciamento de cadastros Prosperisa+</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#6FCF97]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#4F4F4F] font-medium">Total de Cadastros</p>
                <p className="text-3xl font-bold text-[#27AE60] mt-2">{registrations.length}</p>
              </div>
              <FileText className="w-12 h-12 text-[#6FCF97]" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#BB6BD9]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#4F4F4F] font-medium">Com Serviço Funeral</p>
                <p className="text-3xl font-bold text-[#BB6BD9] mt-2">{getServicesCount('servico_funeral')}</p>
              </div>
              <Shield className="w-12 h-12 text-[#BB6BD9]" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#27AE60]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#4F4F4F] font-medium">Com Seguro Pet</p>
                <p className="text-3xl font-bold text-[#27AE60] mt-2">{getServicesCount('servico_pet')}</p>
              </div>
              <Shield className="w-12 h-12 text-[#27AE60]" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#6FCF97] md:col-span-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#4F4F4F] font-medium">Valor Total/Mês</p>
                <p className="text-3xl font-bold text-[#27AE60] mt-2">R$ {getTotalValue().toFixed(2)}</p>
              </div>
              <DollarSign className="w-12 h-12 text-[#6FCF97]" />
            </div>
          </div>
        </div>

        {/* Search and Actions */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#4F4F4F]" />
              <Input
                placeholder="Nome, e-mail ou telefone..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 border-[#E0E0E0] focus:border-[#6FCF97]"
              />
            </div>
            
            <Button
              onClick={selectAll}
              variant="outline"
              className="border-[#6FCF97] text-[#6FCF97] hover:bg-[#6FCF97] hover:text-white"
            >
              {selectedRegistrations.length === filteredRegistrations.length && filteredRegistrations.length > 0 ? "Desmarcar Todos" : "Selecionar Todos"}
            </Button>

            <Dialog open={showExportDialog} onOpenChange={setShowExportDialog}>
              <DialogTrigger asChild>
                <Button
                  disabled={selectedRegistrations.length === 0}
                  className="bg-[#27AE60] hover:bg-[#209450] text-white"
                >
                  <Printer className="w-4 h-4 mr-2" />
                  Exportar Cadastros para PDF
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="text-[#27AE60] flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Exportar Cadastros para PDF
                  </DialogTitle>
                </DialogHeader>
                
                <div className="space-y-4">
                  <div className="bg-[#F2F2F2] p-4 rounded-lg">
                    <p className="text-sm text-[#4F4F4F]">
                      <span className="font-bold text-[#27AE60]">{selectedRegistrations.length}</span> cadastro(s) será(ão) exportado(s).
                    </p>
                    <p className="text-xs text-[#4F4F4F] mt-1">
                      Selecione abaixo os campos que deseja incluir no relatório PDF.
                    </p>
                  </div>

                  {/* Botões Selecionar/Desmarcar Todos */}
                  <div className="flex gap-3">
                    <Button
                      onClick={selectAllFields}
                      variant="outline"
                      className="flex-1 border-[#6FCF97] text-[#6FCF97] hover:bg-[#6FCF97] hover:text-white"
                    >
                      ✓ Selecionar Todos
                    </Button>
                    <Button
                      onClick={deselectAllFields}
                      variant="outline"
                      className="flex-1 border-[#E0E0E0] text-[#4F4F4F] hover:bg-[#F2F2F2]"
                    >
                      Desmarcar Todos
                    </Button>
                  </div>

                  {/* Identificação */}
                  <div className="border-2 border-[#E0E0E0] rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Checkbox
                        id="section_identificacao"
                        checked={exportFields.identificacao && exportFields.identificacao_nome && exportFields.identificacao_email && exportFields.identificacao_celular}
                        onCheckedChange={() => toggleAllInSection('identificacao')}
                        className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                      />
                      <Label htmlFor="section_identificacao" className="text-[#27AE60] font-bold cursor-pointer">
                        Identificação
                      </Label>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 ml-6">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="identificacao_nome"
                          checked={exportFields.identificacao_nome}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, identificacao_nome: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="identificacao_nome" className="cursor-pointer text-sm">Nome Completo</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="identificacao_email"
                          checked={exportFields.identificacao_email}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, identificacao_email: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="identificacao_email" className="cursor-pointer text-sm">E-mail</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="identificacao_celular"
                          checked={exportFields.identificacao_celular}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, identificacao_celular: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="identificacao_celular" className="cursor-pointer text-sm">Celular</Label>
                      </div>
                    </div>
                  </div>

                  {/* Dados Pessoais */}
                  <div className="border-2 border-[#E0E0E0] rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Checkbox
                        id="section_dados_pessoais"
                        checked={exportFields.dados_pessoais && exportFields.dados_pessoais_nascimento && exportFields.dados_pessoais_sexo && exportFields.dados_pessoais_estado_civil}
                        onCheckedChange={() => toggleAllInSection('dados_pessoais')}
                        className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                      />
                      <Label htmlFor="section_dados_pessoais" className="text-[#27AE60] font-bold cursor-pointer">
                        Dados Pessoais
                      </Label>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 ml-6">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="dados_pessoais_nascimento"
                          checked={exportFields.dados_pessoais_nascimento}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, dados_pessoais_nascimento: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="dados_pessoais_nascimento" className="cursor-pointer text-sm">Data de Nascimento</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="dados_pessoais_sexo"
                          checked={exportFields.dados_pessoais_sexo}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, dados_pessoais_sexo: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="dados_pessoais_sexo" className="cursor-pointer text-sm">Sexo</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="dados_pessoais_estado_civil"
                          checked={exportFields.dados_pessoais_estado_civil}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, dados_pessoais_estado_civil: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="dados_pessoais_estado_civil" className="cursor-pointer text-sm">Estado Civil</Label>
                      </div>
                    </div>
                  </div>

                  {/* Endereço */}
                  <div className="border-2 border-[#E0E0E0] rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Checkbox
                        id="section_endereco"
                        checked={exportFields.endereco && exportFields.endereco_completo}
                        onCheckedChange={() => toggleAllInSection('endereco')}
                        className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                      />
                      <Label htmlFor="section_endereco" className="text-[#27AE60] font-bold cursor-pointer">
                        Endereço
                      </Label>
                    </div>
                    
                    <div className="ml-6">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="endereco_completo"
                          checked={exportFields.endereco_completo}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, endereco_completo: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="endereco_completo" className="cursor-pointer text-sm">Endereço Completo</Label>
                      </div>
                    </div>
                  </div>

                  {/* Investimento */}
                  <div className="border-2 border-[#E0E0E0] rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Checkbox
                        id="section_investimento"
                        checked={exportFields.investimento && exportFields.investimento_tempo && exportFields.investimento_valor_objetivo && exportFields.investimento_valor_mensal && exportFields.investimento_vencimento && exportFields.investimento_responsavel && exportFields.investimento_forma_pagamento}
                        onCheckedChange={() => toggleAllInSection('investimento')}
                        className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                      />
                      <Label htmlFor="section_investimento" className="text-[#27AE60] font-bold cursor-pointer">
                        Investimento
                      </Label>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 ml-6">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="investimento_tempo"
                          checked={exportFields.investimento_tempo}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, investimento_tempo: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="investimento_tempo" className="cursor-pointer text-sm">Tempo de Investimento</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="investimento_valor_objetivo"
                          checked={exportFields.investimento_valor_objetivo}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, investimento_valor_objetivo: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="investimento_valor_objetivo" className="cursor-pointer text-sm">Valor Objetivo</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="investimento_valor_mensal"
                          checked={exportFields.investimento_valor_mensal}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, investimento_valor_mensal: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="investimento_valor_mensal" className="cursor-pointer text-sm">Valor Mensal</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="investimento_vencimento"
                          checked={exportFields.investimento_vencimento}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, investimento_vencimento: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="investimento_vencimento" className="cursor-pointer text-sm">Dia de Vencimento</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="investimento_responsavel"
                          checked={exportFields.investimento_responsavel}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, investimento_responsavel: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="investimento_responsavel" className="cursor-pointer text-sm">Responsável Financeiro</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="investimento_forma_pagamento"
                          checked={exportFields.investimento_forma_pagamento}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, investimento_forma_pagamento: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="investimento_forma_pagamento" className="cursor-pointer text-sm">Forma de Pagamento</Label>
                      </div>
                    </div>
                  </div>

                  {/* Serviços Adicionais */}
                  <div className="border-2 border-[#E0E0E0] rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Checkbox
                        id="section_servicos"
                        checked={exportFields.servicos && exportFields.servicos_funeral && exportFields.servicos_pet}
                        onCheckedChange={() => toggleAllInSection('servicos')}
                        className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                      />
                      <Label htmlFor="section_servicos" className="text-[#27AE60] font-bold cursor-pointer">
                        Serviços Adicionais
                      </Label>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 ml-6">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="servicos_funeral"
                          checked={exportFields.servicos_funeral}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, servicos_funeral: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="servicos_funeral" className="cursor-pointer text-sm">Serviço Funeral + Capitalização</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="servicos_pet"
                          checked={exportFields.servicos_pet}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, servicos_pet: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="servicos_pet" className="cursor-pointer text-sm">Seguro Pet</Label>
                      </div>
                    </div>
                  </div>

                  {/* Sistema */}
                  <div className="border-2 border-[#E0E0E0] rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Checkbox
                        id="section_sistema"
                        checked={exportFields.sistema_ip && exportFields.sistema_data_cadastro}
                        onCheckedChange={() => toggleAllInSection('sistema')}
                        className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                      />
                      <Label htmlFor="section_sistema" className="text-[#27AE60] font-bold cursor-pointer">
                        Sistema
                      </Label>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 ml-6">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="sistema_ip"
                          checked={exportFields.sistema_ip}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, sistema_ip: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="sistema_ip" className="cursor-pointer text-sm">IP de Assinatura</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="sistema_data_cadastro"
                          checked={exportFields.sistema_data_cadastro}
                          onCheckedChange={(checked) => setExportFields(prev => ({ ...prev, sistema_data_cadastro: checked }))}
                          className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                        />
                        <Label htmlFor="sistema_data_cadastro" className="cursor-pointer text-sm">Data de Cadastro</Label>
                      </div>
                    </div>
                  </div>

                  {/* Botões de Ação */}
                  <div className="flex justify-between items-center pt-4 border-t">
                    <Button variant="outline" onClick={() => setShowExportDialog(false)}>
                      Cancelar
                    </Button>
                    <Button 
                      onClick={handlePrintSelected}
                      className="bg-[#27AE60] hover:bg-[#209450] text-white gap-2"
                    >
                      <Download className="w-4 h-4" />
                      Gerar PDF ({getSelectedFieldsCount()} campos)
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-[#F2F2F2]">
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedRegistrations.length === filteredRegistrations.length && filteredRegistrations.length > 0}
                      onCheckedChange={selectAll}
                      className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                    />
                  </TableHead>
                  <TableHead className="font-semibold text-[#27AE60]">Nome</TableHead>
                  <TableHead className="font-semibold text-[#27AE60]">E-mail</TableHead>
                  <TableHead className="font-semibold text-[#27AE60]">Celular</TableHead>
                  <TableHead className="font-semibold text-[#27AE60]">Valor Mensal</TableHead>
                  <TableHead className="font-semibold text-[#27AE60]">Serviços</TableHead>
                  <TableHead className="font-semibold text-[#27AE60]">Data Cadastro</TableHead>
                  <TableHead className="font-semibold text-[#27AE60] text-center">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-[#4F4F4F]">
                      Carregando...
                    </TableCell>
                  </TableRow>
                ) : filteredRegistrations.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-[#4F4F4F]">
                      Nenhum cadastro encontrado
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredRegistrations.map((reg) => {
                    const totalMensal = (reg.valor_mensal || 0) + 
                                       (reg.servico_funeral ? 25 : 0) + 
                                       (reg.servico_pet ? 10 : 0);
                    const servicos = [];
                    if (reg.servico_funeral) servicos.push("Funeral");
                    if (reg.servico_pet) servicos.push("Pet");

                    return (
                      <TableRow key={reg.id} className="hover:bg-[#F9FAFB]">
                        <TableCell>
                          <Checkbox
                            checked={selectedRegistrations.includes(reg.id)}
                            onCheckedChange={() => toggleRegistrationSelection(reg.id)}
                            className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
                          />
                        </TableCell>
                        <TableCell className="font-medium">{reg.nome_completo}</TableCell>
                        <TableCell>{reg.email}</TableCell>
                        <TableCell>{reg.celular}</TableCell>
                        <TableCell className="font-semibold text-[#27AE60]">
                          R$ {totalMensal.toFixed(2)}
                        </TableCell>
                        <TableCell>
                          {servicos.length > 0 ? servicos.join(", ") : "Nenhum"}
                        </TableCell>
                        <TableCell className="text-sm">
                          {new Date(reg.created_date).toLocaleDateString("pt-BR")} <br />
                          {new Date(reg.created_date).toLocaleTimeString("pt-BR", { hour: '2-digit', minute: '2-digit' })}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2 justify-center">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  onClick={() => setDetailsRegistration(reg)}
                                  className="border-[#6FCF97] text-[#6FCF97] hover:bg-[#6FCF97] hover:text-white"
                                >
                                  <Eye className="w-4 h-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                                {detailsRegistration && detailsRegistration.id === reg.id && (
                                  <>
                                    <DialogHeader>
                                      <DialogTitle className="text-[#27AE60]">
                                        Detalhes do Cadastro
                                      </DialogTitle>
                                    </DialogHeader>
                                    <div className="space-y-4">
                                      <div className="border-b pb-4">
                                        <h3 className="font-semibold text-[#27AE60] mb-2">Identificação</h3>
                                        <div className="grid grid-cols-2 gap-4 text-sm">
                                          <div>
                                            <p className="text-[#4F4F4F] font-medium">Nome:</p>
                                            <p>{reg.nome_completo}</p>
                                          </div>
                                          <div>
                                            <p className="text-[#4F4F4F] font-medium">CPF:</p>
                                            <p>{reg.cpf}</p>
                                          </div>
                                          <div>
                                            <p className="text-[#4F4F4F] font-medium">Celular:</p>
                                            <p>{reg.celular}</p>
                                          </div>
                                          <div>
                                            <p className="text-[#4F4F4F] font-medium">E-mail:</p>
                                            <p>{reg.email}</p>
                                          </div>
                                        </div>
                                      </div>

                                      <div className="border-b pb-4">
                                        <h3 className="font-semibold text-[#27AE60] mb-2">Dados Pessoais</h3>
                                        <div className="grid grid-cols-2 gap-4 text-sm">
                                          <div>
                                            <p className="text-[#4F4F4F] font-medium">Data de Nascimento:</p>
                                            <p>{reg.data_nascimento ? new Date(reg.data_nascimento + "T00:00:00").toLocaleDateString("pt-BR") : "N/A"}</p>
                                          </div>
                                          <div>
                                            <p className="text-[#4F4F4F] font-medium">Sexo:</p>
                                            <p>{reg.sexo}</p>
                                          </div>
                                          <div>
                                            <p className="text-[#4F4F4F] font-medium">Estado Civil:</p>
                                            <p>{reg.estado_civil}</p>
                                          </div>
                                        </div>
                                      </div>

                                      <div className="border-b pb-4">
                                        <h3 className="font-semibold text-[#27AE60] mb-2">Endereço</h3>
                                        <p className="text-sm">
                                          {reg.endereco?.logradouro}, {reg.endereco?.numero}
                                          {reg.endereco?.complemento && ` - ${reg.endereco.complemento}`}
                                          <br />
                                          {reg.endereco?.bairro}, {reg.endereco?.municipio} - {reg.endereco?.uf}
                                          <br />
                                          CEP: {reg.endereco?.cep}
                                        </p>
                                      </div>

                                      <div className="border-b pb-4">
                                        <h3 className="font-semibold text-[#27AE60] mb-2">Investimento</h3>
                                        <div className="grid grid-cols-2 gap-4 text-sm">
                                          <div>
                                            <p className="text-[#4F4F4F] font-medium">Tempo:</p>
                                            <p>{reg.tempo_investimento_anos} {reg.tempo_investimento_anos === 1 ? "ano" : "anos"}</p>
                                          </div>
                                          <div>
                                            <p className="text-[#4F4F4F] font-medium">Valor Objetivo:</p>
                                            <p>R$ {reg.valor_objetivo?.toFixed(2)}</p>
                                          </div>
                                          <div>
                                            <p className="text-[#4F4F4F] font-medium">Valor Mensal:</p>
                                            <p>R$ {reg.valor_mensal?.toFixed(2)}</p>
                                          </div>
                                          <div>
                                            <p className="text-[#4F4F4F] font-medium">Forma de Pagamento:</p>
                                            <p>{reg.forma_pagamento}</p>
                                          </div>
                                        </div>
                                      </div>

                                      <div>
                                        <h3 className="font-semibold text-[#27AE60] mb-2">Serviços</h3>
                                        <p className="text-sm">
                                          {servicos.length > 0 ? servicos.join(", ") : "Nenhum serviço adicional"}
                                        </p>
                                        <p className="text-lg font-bold text-[#27AE60] mt-2">
                                          Total: R$ {totalMensal.toFixed(2)}/mês
                                        </p>
                                      </div>
                                    </div>
                                  </>
                                )}
                              </DialogContent>
                            </Dialog>

                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => handlePrintSingle(reg)}
                              className="border-[#27AE60] text-[#27AE60] hover:bg-[#27AE60] hover:text-white"
                              title="Imprimir cadastro (PDF)"
                            >
                              <Printer className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  );
}
