
import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { FileText, Shield } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  
  const isAdminPage = location.pathname.includes('Admin');
  const isFormPage = location.pathname.includes('Form');

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error('Error fetching user:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchUser();
  }, []);

  const isAdmin = user && user.role === 'admin';

  return (
    <div className="min-h-screen bg-white">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');
        
        * {
          font-family: 'Poppins', sans-serif;
        }
        
        :root {
          --color-primary: #6FCF97;
          --color-primary-dark: #27AE60;
          --color-gray-light: #F2F2F2;
          --color-gray-medium: #E0E0E0;
          --color-gray-dark: #4F4F4F;
          --color-error: #EB5757;
          --color-accent: #BB6BD9;
        }

        .prosperisa-gradient {
          background: linear-gradient(135deg, rgba(111, 207, 151, 0.1) 0%, rgba(39, 174, 96, 0.05) 100%);
        }
      `}</style>

      {/* Header fixo verde */}
      <header className="bg-[#6FCF97] fixed top-0 left-0 right-0 z-50 shadow-md">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link to={createPageUrl("Form")} className="flex items-center">
            <h1 className="text-white text-2xl font-bold tracking-wide">prosperisa+</h1>
          </Link>
          
          {!isLoading && (
            <nav className="flex items-center gap-6">
              <Link 
                to={createPageUrl("Form")}
                className={`flex items-center gap-2 text-white hover:opacity-80 transition-opacity ${
                  isFormPage ? 'font-semibold' : ''
                }`}
              >
                <FileText className="w-5 h-5" />
                <span>Formulário</span>
              </Link>
              
              {isAdmin && (
                <Link 
                  to={createPageUrl("Admin")}
                  className={`flex items-center gap-2 text-white hover:opacity-80 transition-opacity ${
                    isAdminPage ? 'font-semibold' : ''
                  }`}
                >
                  <Shield className="w-5 h-5" />
                  <span>Administração</span>
                </Link>
              )}
            </nav>
          )}
        </div>
      </header>

      {/* Conteúdo principal */}
      <main className="pt-20">
        {children}
      </main>

      {/* Footer com gradiente sutil */}
      <footer className="prosperisa-gradient mt-20 py-8">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-[#4F4F4F] text-sm">
            © {new Date().getFullYear()} Prosperisa+ - Todos os direitos reservados
          </p>
        </div>
      </footer>
    </div>
  );
}
