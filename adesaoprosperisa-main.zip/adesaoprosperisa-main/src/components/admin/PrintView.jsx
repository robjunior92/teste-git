import React from "react";
import { User, Calendar, MapPin, TrendingUp, Gift } from "lucide-react";

export default function PrintView({ registrations, fields }) {
  return (
    <div className="print-container">
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          .print-container, .print-container * {
            visibility: visible;
          }
          .print-container {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
          @page {
            margin: 0;
          }
        }
        
        .print-page {
          page-break-after: always;
          min-height: 100vh;
        }
        
        .print-page:last-child {
          page-break-after: auto;
        }
      `}</style>

      {registrations.map((reg, index) => (
        <div key={reg.id} className="print-page bg-white">
          {/* Header Verde */}
          <div className="bg-[#6FCF97] text-white py-6 px-8 text-center">
            <h1 className="text-3xl font-bold mb-2">prosperisa+</h1>
            <p className="text-sm">
              Documento gerado em {new Date().toLocaleDateString('pt-BR')} às {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>

          <div className="px-8 py-6">
            <p className="text-center text-sm text-[#4F4F4F] mb-8">
              Prosperisa+ | Confidencial | {new Date().toLocaleDateString('pt-BR')} {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
            </p>

            {/* Título */}
            <div className="flex items-center gap-3 mb-6 pb-4 border-b-2 border-[#27AE60]">
              <User className="w-6 h-6 text-[#27AE60]" />
              <h2 className="text-2xl font-bold text-[#27AE60]">Detalhes do Cadastro</h2>
            </div>

            <div className="space-y-6">
              {/* Identificação */}
              {fields.identificacao && (
                <div className="bg-[#F2F2F2] rounded-lg p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-[#6FCF97] flex items-center justify-center">
                      <User className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-[#27AE60]">Identificação</h3>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    {fields.identificacao_nome && (
                      <div>
                        <p className="text-xs text-[#4F4F4F] font-medium mb-1">Nome Completo</p>
                        <p className="text-sm text-[#4F4F4F]">{reg.nome_completo}</p>
                      </div>
                    )}
                    {fields.identificacao_email && (
                      <div>
                        <p className="text-xs text-[#4F4F4F] font-medium mb-1">E-mail</p>
                        <p className="text-sm text-[#4F4F4F]">{reg.email}</p>
                      </div>
                    )}
                    {fields.identificacao_celular && (
                      <div>
                        <p className="text-xs text-[#4F4F4F] font-medium mb-1">Celular</p>
                        <p className="text-sm text-[#4F4F4F]">{reg.celular}</p>
                      </div>
                    )}
                    {fields.sistema_data_cadastro && (
                      <div>
                        <p className="text-xs text-[#4F4F4F] font-medium mb-1">Data de Cadastro</p>
                        <p className="text-sm text-[#4F4F4F]">
                          {new Date(reg.created_date).toLocaleDateString('pt-BR')} {new Date(reg.created_date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Dados Pessoais */}
              {fields.dados_pessoais && (
                <div className="bg-[#F2F2F2] rounded-lg p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-[#6FCF97] flex items-center justify-center">
                      <Calendar className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-[#27AE60]">Dados Pessoais</h3>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    {fields.dados_pessoais_nascimento && (
                      <div>
                        <p className="text-xs text-[#4F4F4F] font-medium mb-1">Data de Nascimento</p>
                        <p className="text-sm text-[#4F4F4F]">
                          {reg.data_nascimento ? new Date(reg.data_nascimento + 'T00:00:00').toLocaleDateString('pt-BR') : '-'}
                        </p>
                      </div>
                    )}
                    {fields.dados_pessoais_sexo && (
                      <div>
                        <p className="text-xs text-[#4F4F4F] font-medium mb-1">Sexo</p>
                        <p className="text-sm text-[#4F4F4F]">{reg.sexo}</p>
                      </div>
                    )}
                    {fields.dados_pessoais_estado_civil && (
                      <div>
                        <p className="text-xs text-[#4F4F4F] font-medium mb-1">Estado Civil</p>
                        <p className="text-sm text-[#4F4F4F]">{reg.estado_civil}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Endereço */}
              {fields.endereco && fields.endereco_completo && (
                <div className="bg-[#F2F2F2] rounded-lg p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-[#6FCF97] flex items-center justify-center">
                      <MapPin className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-[#27AE60]">Endereço</h3>
                  </div>
                  
                  <div>
                    <p className="text-sm text-[#4F4F4F]">
                      {reg.endereco?.logradouro}, {reg.endereco?.numero} - {reg.endereco?.complemento || 'Casa'}
                    </p>
                    <p className="text-sm text-[#4F4F4F]">
                      {reg.endereco?.bairro}, {reg.endereco?.municipio} - {reg.endereco?.uf}
                    </p>
                    <p className="text-sm text-[#4F4F4F]">
                      CEP: {reg.endereco?.cep}
                    </p>
                  </div>
                </div>
              )}

              {/* Plano de Investimento */}
              {fields.investimento && (
                <div className="bg-[#F2F2F2] rounded-lg p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-[#6FCF97] flex items-center justify-center">
                      <TrendingUp className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-[#27AE60]">Plano de Investimento</h3>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    {fields.investimento_tempo && (
                      <div>
                        <p className="text-xs text-[#4F4F4F] font-medium mb-1">Tempo de Investimento</p>
                        <p className="text-sm text-[#4F4F4F]">{reg.tempo_investimento_anos} anos</p>
                      </div>
                    )}
                    {fields.investimento_valor_objetivo && (
                      <div>
                        <p className="text-xs text-[#4F4F4F] font-medium mb-1">Valor Objetivo</p>
                        <p className="text-sm text-[#4F4F4F]">
                          R$ {(reg.valor_objetivo || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </p>
                      </div>
                    )}
                    {fields.investimento_valor_mensal && (
                      <div>
                        <p className="text-xs text-[#4F4F4F] font-medium mb-1">Valor Mensal</p>
                        <p className="text-sm font-bold text-[#27AE60]">
                          R$ {(reg.valor_mensal || 0).toFixed(2)}
                        </p>
                      </div>
                    )}
                    {fields.investimento_vencimento && (
                      <div>
                        <p className="text-xs text-[#4F4F4F] font-medium mb-1">Dia de Vencimento</p>
                        <p className="text-sm text-[#4F4F4F]">Dia {reg.dia_vencimento}</p>
                      </div>
                    )}
                    {fields.investimento_responsavel && (
                      <div>
                        <p className="text-xs text-[#4F4F4F] font-medium mb-1">Responsável Financeiro</p>
                        <p className="text-sm text-[#4F4F4F]">
                          {reg.responsavel_financeiro ? 'Próprio titular' : reg.responsavel_nome}
                        </p>
                      </div>
                    )}
                    {fields.investimento_forma_pagamento && (
                      <div>
                        <p className="text-xs text-[#4F4F4F] font-medium mb-1">Forma de Pagamento</p>
                        <p className="text-sm text-[#4F4F4F]">{reg.forma_pagamento}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Serviços Adicionais */}
              {fields.servicos && (
                <div className="bg-[#F2F2F2] rounded-lg p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-full bg-[#6FCF97] flex items-center justify-center">
                      <Gift className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-[#27AE60]">Serviços Adicionais</h3>
                  </div>
                  
                  {!reg.servico_funeral && !reg.servico_pet ? (
                    <p className="text-sm text-[#4F4F4F] italic">
                      Nenhum serviço adicional selecionado ou contratado
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {fields.servicos_funeral && reg.servico_funeral && (
                        <p className="text-sm text-[#4F4F4F]">
                          ✓ Seguro Funeral + Título de Capitalização (R$ 25,00/mês)
                        </p>
                      )}
                      {fields.servicos_pet && reg.servico_pet && (
                        <p className="text-sm text-[#4F4F4F]">
                          ✓ Seguro Pet (R$ 10,00/mês)
                        </p>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}