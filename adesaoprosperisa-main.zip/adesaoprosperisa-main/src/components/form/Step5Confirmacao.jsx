import React from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { User, MapPin, TrendingUp, Gift, AlertCircle, Loader2, FileText } from "lucide-react";

export default function Step5Confirmacao({ formData, updateFormData, onPrev, onCancel, onSubmit, isSubmitting }) {
  const canSubmit = () => {
    return formData.aceite_veracidade && formData.aceite_termos;
  };

  const getValorContribuicao = () => {
    return formData.valor_mensal || 0;
  };

  const getValorServicos = () => {
    let total = 0;
    if (formData.servico_funeral) total += 25;
    if (formData.servico_pet) total += 10;
    return total;
  };

  const getTotalMensal = () => {
    return getValorContribuicao() + getValorServicos();
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#27AE60] mb-2">Confirmação</h2>
        <p className="text-[#4F4F4F]">Revise seus dados antes de finalizar</p>
      </div>

      <div className="space-y-4">
        {/* Identificação */}
        <div className="bg-white border-2 border-[#E0E0E0] rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-[#6FCF97] bg-opacity-20 flex items-center justify-center">
              <User className="w-5 h-5 text-[#27AE60]" />
            </div>
            <h3 className="font-bold text-[#27AE60] text-lg">Identificação</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-[#4F4F4F] font-medium">Nome:</p>
              <p className="text-[#4F4F4F]">{formData.nome_completo}</p>
            </div>
            <div>
              <p className="text-[#4F4F4F] font-medium">CPF:</p>
              <p className="text-[#4F4F4F]">{formData.cpf}</p>
            </div>
            <div>
              <p className="text-[#4F4F4F] font-medium">Celular:</p>
              <p className="text-[#4F4F4F]">{formData.celular}</p>
            </div>
            <div>
              <p className="text-[#4F4F4F] font-medium">E-mail:</p>
              <p className="text-[#4F4F4F]">{formData.email}</p>
            </div>
          </div>
        </div>

        {/* Dados Pessoais e Endereço */}
        <div className="bg-white border-2 border-[#E0E0E0] rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-[#6FCF97] bg-opacity-20 flex items-center justify-center">
              <MapPin className="w-5 h-5 text-[#27AE60]" />
            </div>
            <h3 className="font-bold text-[#27AE60] text-lg">Dados Pessoais e Endereço</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm mb-4">
            <div>
              <p className="text-[#4F4F4F] font-medium">Data de nascimento:</p>
              <p className="text-[#4F4F4F]">
                {new Date(formData.data_nascimento + "T00:00:00").toLocaleDateString("pt-BR")}
              </p>
            </div>
            <div>
              <p className="text-[#4F4F4F] font-medium">Sexo:</p>
              <p className="text-[#4F4F4F]">{formData.sexo}</p>
            </div>
            <div className="md:col-span-2">
              <p className="text-[#4F4F4F] font-medium">Estado civil:</p>
              <p className="text-[#4F4F4F]">{formData.estado_civil}</p>
            </div>
          </div>
          <div className="pt-4 border-t border-[#E0E0E0]">
            <p className="text-[#4F4F4F] font-medium mb-2">Endereço:</p>
            <p className="text-[#4F4F4F]">
              {formData.endereco.logradouro}, {formData.endereco.numero}
              {formData.endereco.complemento && ` - ${formData.endereco.complemento}`}
              <br />
              {formData.endereco.bairro}, {formData.endereco.municipio} - {formData.endereco.uf}
              <br />
              CEP: {formData.endereco.cep}
            </p>
          </div>
        </div>

        {/* Plano de Investimento */}
        <div className="bg-white border-2 border-[#E0E0E0] rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-[#6FCF97] bg-opacity-20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-[#27AE60]" />
            </div>
            <h3 className="font-bold text-[#27AE60] text-lg">Plano de Investimento</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-[#4F4F4F] font-medium">Tempo de investimento:</p>
              <p className="text-[#4F4F4F]">
                {formData.tempo_investimento_anos} {formData.tempo_investimento_anos === 1 ? "ano" : "anos"}
              </p>
            </div>
            <div>
              <p className="text-[#4F4F4F] font-medium">Valor objetivo:</p>
              <p className="text-[#4F4F4F]">R$ {formData.valor_objetivo.toFixed(2)}</p>
            </div>
            <div>
              <p className="text-[#4F4F4F] font-medium">Dia de vencimento:</p>
              <p className="text-[#4F4F4F]">Dia {formData.dia_vencimento}</p>
            </div>
            <div>
              <p className="text-[#4F4F4F] font-medium">Responsável financeiro:</p>
              <p className="text-[#4F4F4F]">{formData.responsavel_financeiro ? "Sim" : "Não"}</p>
            </div>
            <div>
              <p className="text-[#4F4F4F] font-medium">Forma de pagamento:</p>
              <p className="text-[#4F4F4F]">{formData.forma_pagamento}</p>
            </div>
            {!formData.responsavel_financeiro && (
              <>
                <div>
                  <p className="text-[#4F4F4F] font-medium">Nome do responsável:</p>
                  <p className="text-[#4F4F4F]">{formData.responsavel_nome}</p>
                </div>
                <div>
                  <p className="text-[#4F4F4F] font-medium">CPF do responsável:</p>
                  <p className="text-[#4F4F4F]">{formData.responsavel_cpf}</p>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Serviços Adicionais */}
        <div className="bg-white border-2 border-[#E0E0E0] rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-[#6FCF97] bg-opacity-20 flex items-center justify-center">
              <Gift className="w-5 h-5 text-[#27AE60]" />
            </div>
            <h3 className="font-bold text-[#27AE60] text-lg">Serviços Adicionais</h3>
          </div>
          {!formData.servico_funeral && !formData.servico_pet ? (
            <p className="text-[#4F4F4F] text-sm">Nenhum serviço adicional contratado.</p>
          ) : (
            <div className="space-y-2 text-sm">
              {formData.servico_funeral && (
                <div className="flex justify-between items-center p-3 bg-[#F2F2F2] rounded">
                  <span className="text-[#4F4F4F]">Seguro Funeral + Título de Capitalização</span>
                  <span className="font-semibold text-[#27AE60]">R$ 25,00/mês</span>
                </div>
              )}
              {formData.servico_pet && (
                <div className="flex justify-between items-center p-3 bg-[#F2F2F2] rounded">
                  <span className="text-[#4F4F4F]">Seguro Pet</span>
                  <span className="font-semibold text-[#27AE60]">R$ 10,00/mês</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Valores Detalhados */}
        <div className="bg-white border-2 border-[#6FCF97] rounded-lg p-6">
          <h3 className="font-bold text-[#27AE60] text-lg mb-4">Resumo de Valores</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center pb-3 border-b border-[#E0E0E0]">
              <span className="text-[#4F4F4F] font-medium">Valor mensal da contribuição:</span>
              <span className="text-lg font-semibold text-[#27AE60]">
                R$ {getValorContribuicao().toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center pb-3 border-b border-[#E0E0E0]">
              <span className="text-[#4F4F4F] font-medium">Serviços adicionais:</span>
              <span className="text-lg font-semibold text-[#27AE60]">
                R$ {getValorServicos().toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center pt-2">
              <span className="text-lg font-bold text-[#27AE60]">Total Mensal:</span>
              <span className="text-2xl font-bold text-[#27AE60]">
                R$ {getTotalMensal().toFixed(2)}
              </span>
            </div>
          </div>
        </div>

        {/* Aceites */}
        <div className="space-y-4 pt-4">
          <div className="flex items-start gap-3 p-4 bg-[#F2F2F2] rounded-lg">
            <Checkbox
              id="aceite_veracidade"
              checked={formData.aceite_veracidade}
              onCheckedChange={(checked) => updateFormData({ aceite_veracidade: checked })}
              className="mt-1 border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
            />
            <Label 
              htmlFor="aceite_veracidade" 
              className="text-sm text-[#4F4F4F] cursor-pointer flex-1"
            >
              Atesto a veracidade dos dados acima.
            </Label>
          </div>

          <Dialog>
            <div className="flex items-start gap-3 p-4 bg-[#F2F2F2] rounded-lg">
              <Checkbox
                id="aceite_termos"
                checked={formData.aceite_termos}
                onCheckedChange={(checked) => updateFormData({ aceite_termos: checked })}
                className="mt-1 border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
              />
              <Label 
                htmlFor="aceite_termos" 
                className="text-sm text-[#4F4F4F] cursor-pointer flex-1"
              >
                Estou de acordo com os{" "}
                <DialogTrigger asChild>
                  <span className="text-[#6FCF97] underline cursor-pointer hover:text-[#27AE60]">
                    termos de adesão ao plano Prosperisa+
                  </span>
                </DialogTrigger>
                .
              </Label>
            </div>
            
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-[#27AE60] flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Termos de Adesão ao Plano Prosperisa+
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 text-sm text-[#4F4F4F]">
                <section>
                  <h3 className="font-semibold text-[#27AE60] mb-2">1. OBJETO DO CONTRATO</h3>
                  <p>O presente termo estabelece as condições de adesão ao plano de previdência privada Prosperisa+, com objetivo de acumulação de recursos para a realização de objetivos futuros do participante.</p>
                </section>

                <section>
                  <h3 className="font-semibold text-[#27AE60] mb-2">2. CONTRIBUIÇÕES</h3>
                  <p>O participante se compromete a efetuar contribuições mensais no valor acordado, sendo o valor mínimo de R$ 50,00 (cinquenta reais), na data de vencimento escolhida durante a adesão.</p>
                  <p className="mt-2">As contribuições poderão ser reajustadas anualmente, conforme índices econômicos vigentes e regulamentação da Superintendência de Seguros Privados (SUSEP).</p>
                </section>

                <section>
                  <h3 className="font-semibold text-[#27AE60] mb-2">3. RENTABILIDADE</h3>
                  <p>Os recursos investidos serão aplicados conforme a política de investimentos da Prosperisa+, com rentabilidade estimada de 0,80% ao mês, podendo variar conforme as condições do mercado financeiro.</p>
                  <p className="mt-2">A rentabilidade passada não garante rentabilidade futura.</p>
                </section>

                <section>
                  <h3 className="font-semibold text-[#27AE60] mb-2">4. SERVIÇOS ADICIONAIS</h3>
                  <p>O participante poderá contratar serviços adicionais mediante pagamento de valores extras mensais:</p>
                  <ul className="list-disc ml-6 mt-2 space-y-1">
                    <li>Seguro Funeral + Título de Capitalização: R$ 25,00/mês</li>
                    <li>Seguro Pet: R$ 10,00/mês</li>
                  </ul>
                  <p className="mt-2">Os serviços adicionais estão sujeitos a termos e condições específicos fornecidos pelos prestadores.</p>
                </section>

                <section>
                  <h3 className="font-semibold text-[#27AE60] mb-2">5. RESGATE</h3>
                  <p>O participante poderá solicitar o resgate total ou parcial dos valores acumulados a qualquer momento, observado o prazo de carência de 60 (sessenta) dias após a primeira contribuição.</p>
                  <p className="mt-2">O resgate está sujeito às taxas e impostos vigentes na data da solicitação.</p>
                </section>

                <section>
                  <h3 className="font-semibold text-[#27AE60] mb-2">6. PORTABILIDADE</h3>
                  <p>É assegurado ao participante o direito de portabilidade dos recursos para outro plano de previdência, conforme regulamentação da SUSEP.</p>
                </section>

                <section>
                  <h3 className="font-semibold text-[#27AE60] mb-2">7. CANCELAMENTO</h3>
                  <p>O participante poderá cancelar o plano a qualquer momento, mediante solicitação formal. O cancelamento não implica em perda dos valores já acumulados, que poderão ser resgatados conforme item 5.</p>
                </section>

                <section>
                  <h3 className="font-semibold text-[#27AE60] mb-2">8. INADIMPLÊNCIA</h3>
                  <p>Em caso de inadimplência superior a 60 (sessenta) dias, o plano será automaticamente suspenso, sendo reativado mediante regularização dos pagamentos em atraso.</p>
                </section>

                <section>
                  <h3 className="font-semibold text-[#27AE60] mb-2">9. PROTEÇÃO DE DADOS</h3>
                  <p>Todos os dados pessoais fornecidos serão tratados conforme a Lei Geral de Proteção de Dados (LGPD - Lei 13.709/2018), garantindo a privacidade e segurança das informações.</p>
                </section>

                <section>
                  <h3 className="font-semibold text-[#27AE60] mb-2">10. FORO</h3>
                  <p>Fica eleito o foro da comarca de residência do participante para dirimir quaisquer questões oriundas do presente contrato.</p>
                </section>

                <div className="bg-[#6FCF97] bg-opacity-10 p-4 rounded-lg mt-6">
                  <p className="text-[#27AE60] font-medium">
                    Ao aceitar estes termos, você declara ter lido, compreendido e concordado com todas as condições aqui estabelecidas.
                  </p>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {!canSubmit() && (
          <div className="bg-[#EB5757] bg-opacity-10 border border-[#EB5757] rounded-md p-4">
            <p className="text-[#EB5757] text-sm flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              Você precisa aceitar os termos para concluir o cadastro
            </p>
          </div>
        )}
      </div>

      <div className="flex justify-between pt-6 border-t border-[#E0E0E0]">
        <div className="flex gap-4">
          <Button
            onClick={onCancel}
            variant="outline"
            disabled={isSubmitting}
            className="border-[#27AE60] text-[#27AE60] hover:bg-[#27AE60] hover:text-white"
          >
            CANCELAR
          </Button>
          <Button
            onClick={onPrev}
            variant="outline"
            disabled={isSubmitting}
            className="border-[#6FCF97] text-[#6FCF97] hover:bg-[#6FCF97] hover:text-white"
          >
            VOLTAR
          </Button>
        </div>
        <Button
          onClick={onSubmit}
          disabled={!canSubmit() || isSubmitting}
          className={`${
            canSubmit() && !isSubmitting
              ? "bg-[#27AE60] hover:bg-[#27AE60] text-white" 
              : "bg-[#F2F2F2] text-[#4F4F4F] cursor-not-allowed"
          }`}
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              PROCESSANDO...
            </>
          ) : (
            "CONCLUIR CADASTRO"
          )}
        </Button>
      </div>
    </div>
  );
}