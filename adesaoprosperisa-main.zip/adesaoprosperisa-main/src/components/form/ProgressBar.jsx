import React from "react";
import { Check, User, MapPin, TrendingUp, Gift, FileCheck } from "lucide-react";

const steps = [
  { number: 1, label: "Identificação", icon: User },
  { number: 2, label: "Meus dados", icon: MapPin },
  { number: 3, label: "Investimento", icon: TrendingUp },
  { number: 4, label: "Serviços", icon: Gift },
  { number: 5, label: "Confirmação", icon: FileCheck }
];

export default function ProgressBar({ currentStep }) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => {
          const Icon = step.icon;
          const isActive = currentStep === step.number;
          const isCompleted = currentStep > step.number;
          
          return (
            <React.Fragment key={step.number}>
              <div className="flex flex-col items-center flex-1">
                <div 
                  className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 transition-all ${
                    isCompleted 
                      ? "bg-[#27AE60] text-white" 
                      : isActive 
                      ? "bg-[#6FCF97] text-white" 
                      : "bg-[#E0E0E0] text-[#4F4F4F]"
                  }`}
                >
                  {isCompleted ? (
                    <Check className="w-6 h-6" />
                  ) : (
                    <Icon className="w-6 h-6" />
                  )}
                </div>
                <span 
                  className={`text-xs font-medium text-center ${
                    isActive ? "text-[#27AE60]" : "text-[#4F4F4F]"
                  }`}
                >
                  {step.label}
                </span>
              </div>
              
              {index < steps.length - 1 && (
                <div 
                  className={`h-1 flex-1 mx-2 mt-[-20px] transition-all ${
                    currentStep > step.number ? "bg-[#27AE60]" : "bg-[#E0E0E0]"
                  }`}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}