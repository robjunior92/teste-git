import React from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Check, Shield, Heart } from "lucide-react";

export default function Step4Servicos({ formData, updateFormData, onNext, onPrev, onCancel }) {
  const getTotalServicos = () => {
    let total = 0;
    if (formData.servico_funeral) total += 25;
    if (formData.servico_pet) total += 10;
    return total;
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#27AE60] mb-2">Serviços adicionais</h2>
        <p className="text-[#4F4F4F]">Proteção Completa para Você e sua Família</p>
      </div>

      <div className="bg-[#F9FAFB] p-6 rounded-lg border border-[#E0E0E0]">
        <p className="text-[#4F4F4F] mb-6">
          Incremente seu plano com serviços exclusivos que oferecem mais segurança e benefícios para você e quem você ama.
        </p>

        <div className="space-y-4">
          {/* Serviço Funeral + Título de Capitalização */}
          <div 
            className={`border-2 rounded-lg p-6 transition-all cursor-pointer ${
              formData.servico_funeral 
                ? "border-[#6FCF97] bg-[#6FCF97] bg-opacity-5" 
                : "border-[#E0E0E0] hover:border-[#6FCF97]"
            }`}
            onClick={() => updateFormData({ servico_funeral: !formData.servico_funeral })}
          >
            <div className="flex items-start gap-4">
              <div className="flex items-center gap-3 flex-1">
                <div className="w-12 h-12 rounded-full bg-[#BB6BD9] bg-opacity-20 flex items-center justify-center">
                  <Shield className="w-6 h-6 text-[#BB6BD9]" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-[#27AE60] text-lg mb-1">
                    Seguro Funeral + Título de Capitalização
                  </h3>
                  <p className="text-[#4F4F4F] text-sm mb-3">
                    Cobertura completa para imprevistos com tranquilidade e sorteios semanais de até R$ 10.000,00
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-3">
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-[#27AE60]" />
                      <span className="text-sm text-[#4F4F4F]">Assistência funeral completa</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-[#27AE60]" />
                      <span className="text-sm text-[#4F4F4F]">Sorteios semanais</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-[#27AE60]" />
                      <span className="text-sm text-[#4F4F4F]">Cobertura 24 horas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-[#27AE60]" />
                      <span className="text-sm text-[#4F4F4F]">Prêmios de até R$ 10.000</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                <Checkbox
                  checked={formData.servico_funeral}
                  onCheckedChange={(checked) => updateFormData({ servico_funeral: checked })}
                  className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97] w-6 h-6"
                  onClick={(e) => e.stopPropagation()}
                />
                <div className="text-right">
                  <p className="text-2xl font-bold text-[#27AE60]">R$ 25,00</p>
                  <p className="text-sm text-[#4F4F4F]">por mês</p>
                </div>
              </div>
            </div>
          </div>

          {/* Seguro Pet */}
          <div 
            className={`border-2 rounded-lg p-6 transition-all cursor-pointer ${
              formData.servico_pet 
                ? "border-[#6FCF97] bg-[#6FCF97] bg-opacity-5" 
                : "border-[#E0E0E0] hover:border-[#6FCF97]"
            }`}
            onClick={() => updateFormData({ servico_pet: !formData.servico_pet })}
          >
            <div className="flex items-start gap-4">
              <div className="flex items-center gap-3 flex-1">
                <div className="w-12 h-12 rounded-full bg-[#6FCF97] bg-opacity-20 flex items-center justify-center">
                  <Heart className="w-6 h-6 text-[#6FCF97]" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-[#27AE60] text-lg mb-1">
                    Seguro Pet
                  </h3>
                  <p className="text-[#4F4F4F] text-sm mb-3">
                    Proteção e cuidado completo para o seu melhor amigo de quatro patas
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-3">
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-[#27AE60]" />
                      <span className="text-sm text-[#4F4F4F]">Consultas veterinárias</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-[#27AE60]" />
                      <span className="text-sm text-[#4F4F4F]">Exames de emergência</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-[#27AE60]" />
                      <span className="text-sm text-[#4F4F4F]">Internações veterinárias</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-[#27AE60]" />
                      <span className="text-sm text-[#4F4F4F]">Telemedicina vet 24h</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                <Checkbox
                  checked={formData.servico_pet}
                  onCheckedChange={(checked) => updateFormData({ servico_pet: checked })}
                  className="border-[#6FCF97] data-[state=checked]:bg-[#6FCF97] w-6 h-6"
                  onClick={(e) => e.stopPropagation()}
                />
                <div className="text-right">
                  <p className="text-2xl font-bold text-[#27AE60]">R$ 10,00</p>
                  <p className="text-sm text-[#4F4F4F]">por mês</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {getTotalServicos() > 0 && (
          <div className="mt-6 p-4 bg-[#6FCF97] bg-opacity-10 rounded-lg border-l-4 border-[#6FCF97]">
            <p className="text-[#27AE60] font-semibold">
              Total de serviços adicionais: R$ {getTotalServicos().toFixed(2)}/mês
            </p>
          </div>
        )}

        <div className="mt-6 p-4 bg-white rounded-lg border border-[#E0E0E0]">
          <p className="text-sm text-[#4F4F4F] italic">
            <strong>Nota:</strong> Estes serviços são opcionais. Você pode selecionar nenhum, um ou todos os serviços adicionais. 
            Os valores serão somados ao seu investimento mensal.
          </p>
        </div>
      </div>

      <div className="flex justify-between pt-6 border-t border-[#E0E0E0]">
        <div className="flex gap-4">
          <Button
            onClick={onCancel}
            variant="outline"
            className="border-[#27AE60] text-[#27AE60] hover:bg-[#27AE60] hover:text-white"
          >
            CANCELAR
          </Button>
          <Button
            onClick={onPrev}
            variant="outline"
            className="border-[#6FCF97] text-[#6FCF97] hover:bg-[#6FCF97] hover:text-white"
          >
            VOLTAR
          </Button>
        </div>
        <Button
          onClick={onNext}
          className="bg-[#6FCF97] hover:bg-[#27AE60] text-white"
        >
          AVANÇAR
        </Button>
      </div>
    </div>
  );
}