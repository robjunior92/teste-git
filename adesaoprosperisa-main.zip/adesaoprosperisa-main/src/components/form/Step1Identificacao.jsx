import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertCircle, CheckCircle2, Loader2, Phone, Mail } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function Step1Identificacao({ formData, updateFormData, onNext, onCancel }) {
  const [errors, setErrors] = useState({});
  
  // SMS Verification States
  const [smsCodeSent, setSmsCodeSent] = useState(false);
  const [smsVerificationCode, setSmsVerificationCode] = useState("");
  const [phoneVerified, setPhoneVerified] = useState(false);
  const [isSendingSmsCode, setIsSendingSmsCode] = useState(false);
  const [isValidatingSmsCode, setIsValidatingSmsCode] = useState(false);
  const [smsVerificationMessage, setSmsVerificationMessage] = useState("");

  // Email Verification States
  const [emailCodeSent, setEmailCodeSent] = useState(false);
  const [emailVerificationCode, setEmailVerificationCode] = useState("");
  const [emailVerified, setEmailVerified] = useState(false);
  const [isSendingEmailCode, setIsSendingEmailCode] = useState(false);
  const [isValidatingEmailCode, setIsValidatingEmailCode] = useState(false);
  const [emailVerificationMessage, setEmailVerificationMessage] = useState("");

  const validateName = (name) => {
    if (!name) return "Nome completo é obrigatório";
    if (/\d/.test(name)) return "Nome não pode conter números";
    const parts = name.trim().split(" ");
    if (parts.length < 2) return "Digite nome e sobrenome";
    if (parts.some(part => part.length < 2)) return "Nome e sobrenome devem ter pelo menos 2 caracteres";
    return "";
  };

  const validateCPF = (cpf) => {
    const cleaned = cpf.replace(/\D/g, "");
    if (cleaned.length !== 11) return "CPF deve ter 11 dígitos";
    
    if (/^(\d)\1+$/.test(cleaned)) return "CPF inválido";
    
    let sum = 0;
    for (let i = 0; i < 9; i++) {
      sum += parseInt(cleaned.charAt(i)) * (10 - i);
    }
    let digit = 11 - (sum % 11);
    if (digit > 9) digit = 0;
    if (digit !== parseInt(cleaned.charAt(9))) return "CPF inválido";
    
    sum = 0;
    for (let i = 0; i < 10; i++) {
      sum += parseInt(cleaned.charAt(i)) * (11 - i);
    }
    digit = 11 - (sum % 11);
    if (digit > 9) digit = 0;
    if (digit !== parseInt(cleaned.charAt(10))) return "CPF inválido";
    
    return "";
  };

  const validatePhone = (phone) => {
    const cleaned = phone.replace(/\D/g, "");
    if (cleaned.length !== 11) return "Celular deve ter DDD + 9 dígitos";
    return "";
  };

  const validateEmail = (email) => {
    if (!email) return "E-mail é obrigatório";
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) return "E-mail inválido";
    return "";
  };

  const formatCPF = (value) => {
    const cleaned = value.replace(/\D/g, "");
    return cleaned
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d{1,2})/, "$1-$2")
      .replace(/(-\d{2})\d+?$/, "$1");
  };

  const formatPhone = (value) => {
    const cleaned = value.replace(/\D/g, "");
    return cleaned
      .replace(/(\d{2})(\d)/, "($1) $2")
      .replace(/(\d{5})(\d)/, "$1-$2")
      .replace(/(-\d{4})\d+?$/, "$1");
  };

  const handleFieldChange = (field, value) => {
    let formattedValue = value;
    
    if (field === "cpf") {
      formattedValue = formatCPF(value);
    } else if (field === "celular") {
      formattedValue = formatPhone(value);
      if (formattedValue !== formData.celular) {
        setSmsCodeSent(false);
        setPhoneVerified(false);
        setSmsVerificationCode("");
        setSmsVerificationMessage("");
      }
    } else if (field === "email") {
      if (value !== formData.email) {
        setEmailCodeSent(false);
        setEmailVerified(false);
        setEmailVerificationCode("");
        setEmailVerificationMessage("");
      }
    }
    
    updateFormData({ [field]: formattedValue });
    
    let error = "";
    if (field === "nome_completo") error = validateName(formattedValue);
    else if (field === "cpf") error = validateCPF(formattedValue);
    else if (field === "celular") error = validatePhone(formattedValue);
    else if (field === "email") error = validateEmail(formattedValue);
    
    setErrors(prev => ({ ...prev, [field]: error }));
  };

  // SMS Verification Handlers
  const handleSendSmsVerificationCode = async () => {
    const phoneError = validatePhone(formData.celular);
    if (phoneError) {
      setErrors(prev => ({ ...prev, celular: phoneError }));
      return;
    }

    setIsSendingSmsCode(true);
    setSmsVerificationMessage("");

    try {
      const response = await base44.functions.invoke('sendSMSVerification', {
        phoneNumber: formData.celular
      });

      if (response.data.success) {
        setSmsCodeSent(true);
        setSmsVerificationMessage(response.data.message);
      } else {
        setSmsVerificationMessage(response.data.message || "Não foi possível enviar o código. Tente novamente.");
      }
    } catch (error) {
      setSmsVerificationMessage("Não foi possível enviar o código. Tente novamente.");
    } finally {
      setIsSendingSmsCode(false);
    }
  };

  const handleValidateSmsCode = async () => {
    if (smsVerificationCode.length !== 6) {
      setSmsVerificationMessage("Digite o código de 6 dígitos");
      return;
    }

    setIsValidatingSmsCode(true);
    setSmsVerificationMessage("");

    try {
      const response = await base44.functions.invoke('validateSMSCode', {
        phoneNumber: formData.celular,
        code: smsVerificationCode
      });

      if (response.data.success) {
        setPhoneVerified(true);
        setSmsVerificationMessage(response.data.message);
      } else {
        setSmsVerificationMessage(response.data.message || "Código incorreto. Tente novamente.");
      }
    } catch (error) {
      setSmsVerificationMessage("Erro ao validar código. Tente novamente.");
    } finally {
      setIsValidatingSmsCode(false);
    }
  };

  // Email Verification Handlers
  const handleSendEmailVerificationCode = async () => {
    const emailError = validateEmail(formData.email);
    if (emailError) {
      setErrors(prev => ({ ...prev, email: emailError }));
      return;
    }

    setIsSendingEmailCode(true);
    setEmailVerificationMessage("");

    try {
      const response = await base44.functions.invoke('sendEmailVerification', {
        email: formData.email
      });

      if (response.data.success) {
        setEmailCodeSent(true);
        setEmailVerificationMessage(response.data.message);
      } else {
        setEmailVerificationMessage(response.data.message || "Não foi possível enviar o código. Tente novamente.");
      }
    } catch (error) {
      setEmailVerificationMessage("Não foi possível enviar o código. Tente novamente.");
    } finally {
      setIsSendingEmailCode(false);
    }
  };

  const handleValidateEmailCode = async () => {
    if (emailVerificationCode.length !== 6) {
      setEmailVerificationMessage("Digite o código de 6 dígitos");
      return;
    }

    setIsValidatingEmailCode(true);
    setEmailVerificationMessage("");

    try {
      const response = await base44.functions.invoke('validateEmailCode', {
        email: formData.email,
        code: emailVerificationCode
      });

      if (response.data.success) {
        setEmailVerified(true);
        setEmailVerificationMessage(response.data.message);
      } else {
        setEmailVerificationMessage(response.data.message || "Código incorreto. Tente novamente.");
      }
    } catch (error) {
      setEmailVerificationMessage("Erro ao validar código. Tente novamente.");
    } finally {
      setIsValidatingEmailCode(false);
    }
  };

  const canProceed = () => {
    return (
      !validateName(formData.nome_completo) &&
      !validateCPF(formData.cpf) &&
      !validatePhone(formData.celular) &&
      !validateEmail(formData.email) &&
      formData.aceite_privacidade &&
      phoneVerified &&
      emailVerified
    );
  };

  const handleNext = () => {
    const allErrors = {
      nome_completo: validateName(formData.nome_completo),
      cpf: validateCPF(formData.cpf),
      celular: validatePhone(formData.celular),
      email: validateEmail(formData.email)
    };
    
    setErrors(allErrors);
    
    if (!phoneVerified) {
      alert("Por favor, valide seu número de celular antes de continuar.");
      return;
    }

    if (!emailVerified) {
      alert("Por favor, valide seu e-mail antes de continuar.");
      return;
    }
    
    if (canProceed()) {
      onNext();
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#27AE60] mb-2">Identificação</h2>
        <p className="text-[#4F4F4F]">Preencha seus dados pessoais para começar</p>
      </div>

      <div className="space-y-4">
        <div>
          <Label htmlFor="nome_completo" className="text-[#4F4F4F] font-medium">
            Nome completo *
          </Label>
          <Input
            id="nome_completo"
            value={formData.nome_completo}
            onChange={(e) => handleFieldChange("nome_completo", e.target.value)}
            placeholder="Digite seu nome completo"
            className={`mt-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] ${
              errors.nome_completo ? "border-[#EB5757]" : "border-[#E0E0E0]"
            }`}
          />
          {errors.nome_completo && (
            <p className="text-[#EB5757] text-sm mt-1 flex items-center gap-1">
              <AlertCircle className="w-4 h-4" />
              {errors.nome_completo}
            </p>
          )}
        </div>

        <div>
          <Label htmlFor="cpf" className="text-[#4F4F4F] font-medium">
            CPF *
          </Label>
          <Input
            id="cpf"
            value={formData.cpf}
            onChange={(e) => handleFieldChange("cpf", e.target.value)}
            placeholder="000.000.000-00"
            maxLength={14}
            className={`mt-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] ${
              errors.cpf ? "border-[#EB5757]" : "border-[#E0E0E0]"
            }`}
          />
          {errors.cpf && (
            <p className="text-[#EB5757] text-sm mt-1 flex items-center gap-1">
              <AlertCircle className="w-4 h-4" />
              {errors.cpf}
            </p>
          )}
        </div>

        {/* Celular com verificação SMS */}
        <div>
          <Label htmlFor="celular" className="text-[#4F4F4F] font-medium">
            Celular *
          </Label>
          <div className="flex gap-2 mt-1">
            <Input
              id="celular"
              value={formData.celular}
              onChange={(e) => handleFieldChange("celular", e.target.value)}
              placeholder="(00) 00000-0000"
              maxLength={15}
              disabled={phoneVerified}
              className={`flex-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] ${
                errors.celular ? "border-[#EB5757]" : phoneVerified ? "border-[#27AE60]" : "border-[#E0E0E0]"
              }`}
            />
            {!phoneVerified && (
              <Button
                type="button"
                onClick={handleSendSmsVerificationCode}
                disabled={isSendingSmsCode || validatePhone(formData.celular) !== "" || smsCodeSent}
                className="bg-[#6FCF97] hover:bg-[#27AE60] text-white"
              >
                {isSendingSmsCode ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Enviando...
                  </>
                ) : smsCodeSent ? (
                  "Código Enviado"
                ) : (
                  <>
                    <Phone className="w-4 h-4 mr-2" />
                    Enviar Código
                  </>
                )}
              </Button>
            )}
            {phoneVerified && (
              <div className="flex items-center gap-2 text-[#27AE60] px-4">
                <CheckCircle2 className="w-5 h-5" />
                <span className="text-sm font-medium">Verificado</span>
              </div>
            )}
          </div>
          {errors.celular && (
            <p className="text-[#EB5757] text-sm mt-1 flex items-center gap-1">
              <AlertCircle className="w-4 h-4" />
              {errors.celular}
            </p>
          )}

          {smsCodeSent && !phoneVerified && (
            <div className="mt-4 p-4 bg-[#F2F2F2] rounded-lg border border-[#E0E0E0]">
              <Label htmlFor="sms_verification_code" className="text-[#4F4F4F] font-medium">
                Código de verificação SMS (6 dígitos)
              </Label>
              <div className="flex gap-2 mt-2">
                <Input
                  id="sms_verification_code"
                  value={smsVerificationCode}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, '').slice(0, 6);
                    setSmsVerificationCode(value);
                  }}
                  placeholder="000000"
                  maxLength={6}
                  className="flex-1 border-[#E0E0E0] focus:border-[#6FCF97]"
                />
                <Button
                  type="button"
                  onClick={handleValidateSmsCode}
                  disabled={isValidatingSmsCode || smsVerificationCode.length !== 6}
                  className="bg-[#27AE60] hover:bg-[#209450] text-white"
                >
                  {isValidatingSmsCode ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Validando...
                    </>
                  ) : (
                    "Validar Código"
                  )}
                </Button>
              </div>
              <Button
                type="button"
                variant="link"
                onClick={handleSendSmsVerificationCode}
                disabled={isSendingSmsCode}
                className="text-[#6FCF97] hover:text-[#27AE60] p-0 h-auto mt-2"
              >
                Reenviar código
              </Button>
            </div>
          )}

          {smsVerificationMessage && (
            <div className={`mt-2 p-3 rounded-lg flex items-center gap-2 ${
              phoneVerified 
                ? "bg-[#27AE60] bg-opacity-10 text-[#27AE60]" 
                : "bg-[#EB5757] bg-opacity-10 text-[#EB5757]"
            }`}>
              {phoneVerified ? (
                <CheckCircle2 className="w-4 h-4" />
              ) : (
                <AlertCircle className="w-4 h-4" />
              )}
              <span className="text-sm">{smsVerificationMessage}</span>
            </div>
          )}
        </div>

        {/* E-mail com verificação */}
        <div>
          <Label htmlFor="email" className="text-[#4F4F4F] font-medium">
            E-mail *
          </Label>
          <div className="flex gap-2 mt-1">
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleFieldChange("email", e.target.value)}
              placeholder="seu.email@exemplo.com"
              disabled={emailVerified}
              className={`flex-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] ${
                errors.email ? "border-[#EB5757]" : emailVerified ? "border-[#27AE60]" : "border-[#E0E0E0]"
              }`}
            />
            {!emailVerified && (
              <Button
                type="button"
                onClick={handleSendEmailVerificationCode}
                disabled={isSendingEmailCode || validateEmail(formData.email) !== "" || emailCodeSent}
                className="bg-[#6FCF97] hover:bg-[#27AE60] text-white"
              >
                {isSendingEmailCode ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Enviando...
                  </>
                ) : emailCodeSent ? (
                  "Código Enviado"
                ) : (
                  <>
                    <Mail className="w-4 h-4 mr-2" />
                    Enviar Código
                  </>
                )}
              </Button>
            )}
            {emailVerified && (
              <div className="flex items-center gap-2 text-[#27AE60] px-4">
                <CheckCircle2 className="w-5 h-5" />
                <span className="text-sm font-medium">Verificado</span>
              </div>
            )}
          </div>
          {errors.email && (
            <p className="text-[#EB5757] text-sm mt-1 flex items-center gap-1">
              <AlertCircle className="w-4 h-4" />
              {errors.email}
            </p>
          )}

          {emailCodeSent && !emailVerified && (
            <div className="mt-4 p-4 bg-[#F2F2F2] rounded-lg border border-[#E0E0E0]">
              <Label htmlFor="email_verification_code" className="text-[#4F4F4F] font-medium">
                Código de verificação do e-mail (6 dígitos)
              </Label>
              <div className="flex gap-2 mt-2">
                <Input
                  id="email_verification_code"
                  value={emailVerificationCode}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, '').slice(0, 6);
                    setEmailVerificationCode(value);
                  }}
                  placeholder="000000"
                  maxLength={6}
                  className="flex-1 border-[#E0E0E0] focus:border-[#6FCF97]"
                />
                <Button
                  type="button"
                  onClick={handleValidateEmailCode}
                  disabled={isValidatingEmailCode || emailVerificationCode.length !== 6}
                  className="bg-[#27AE60] hover:bg-[#209450] text-white"
                >
                  {isValidatingEmailCode ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Validando...
                    </>
                  ) : (
                    "Validar Código"
                  )}
                </Button>
              </div>
              <Button
                type="button"
                variant="link"
                onClick={handleSendEmailVerificationCode}
                disabled={isSendingEmailCode}
                className="text-[#6FCF97] hover:text-[#27AE60] p-0 h-auto mt-2"
              >
                Reenviar código
              </Button>
            </div>
          )}

          {emailVerificationMessage && (
            <div className={`mt-2 p-3 rounded-lg flex items-center gap-2 ${
              emailVerified 
                ? "bg-[#27AE60] bg-opacity-10 text-[#27AE60]" 
                : "bg-[#EB5757] bg-opacity-10 text-[#EB5757]"
            }`}>
              {emailVerified ? (
                <CheckCircle2 className="w-4 h-4" />
              ) : (
                <AlertCircle className="w-4 h-4" />
              )}
              <span className="text-sm">{emailVerificationMessage}</span>
            </div>
          )}
        </div>

        <div className="bg-[#F2F2F2] p-4 rounded-md max-h-48 overflow-y-auto border border-[#E0E0E0]">
          <h3 className="font-semibold text-[#27AE60] mb-2">POLÍTICA DE PRIVACIDADE DE DADOS</h3>
          <div className="text-sm text-[#4F4F4F] space-y-2">
            <p><strong>1. COLETA DE DADOS</strong></p>
            <p>Todos os dados pessoais informados são coletados exclusivamente para fins de processamento da adesão ao plano Prosperisa+ e serão tratados conforme a Lei Geral de Proteção de Dados (LGPD - Lei 13.709/2018).</p>
            
            <p><strong>2. USO DOS DADOS</strong></p>
            <p>Seus dados serão utilizados exclusivamente para: processamento de sua inscrição; envio de comunicações importantes sobre seu plano; cumprimento de obrigações legais e regulatórias.</p>
            
            <p><strong>3. COMPARTILHAMENTO</strong></p>
            <p>Seus dados poderão ser compartilhados apenas com parceiros essenciais para a operação do serviço, sempre com total segurança e confidencialidade.</p>
            
            <p><strong>4. SEGURANÇA</strong></p>
            <p>Utilizamos tecnologias de criptografia e controles de segurança rigorosos para proteger suas informações pessoais.</p>
            
            <p><strong>5. SEUS DIREITOS</strong></p>
            <p>Você tem direito a acessar, corrigir, deletar ou solicitar a portabilidade de seus dados a qualquer momento, conforme a LGPD.</p>
          </div>
        </div>

        <div className="flex items-start gap-3 pt-2">
          <Checkbox
            id="aceite_privacidade"
            checked={formData.aceite_privacidade}
            onCheckedChange={(checked) => updateFormData({ aceite_privacidade: checked })}
            className="mt-1 border-[#6FCF97] data-[state=checked]:bg-[#6FCF97]"
          />
          <Label 
            htmlFor="aceite_privacidade" 
            className="text-sm text-[#4F4F4F] cursor-pointer"
          >
            Estou de acordo com a política de privacidade de dados.
          </Label>
        </div>

        {!formData.aceite_privacidade && Object.keys(errors).length > 0 && (
          <div className="bg-[#EB5757] bg-opacity-10 border border-[#EB5757] rounded-md p-3">
            <p className="text-[#EB5757] text-sm flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              Você precisa aceitar a política de privacidade para continuar
            </p>
          </div>
        )}

        {(!phoneVerified || !emailVerified) && formData.celular && formData.email && !validatePhone(formData.celular) && !validateEmail(formData.email) && (
          <div className="bg-[#6FCF97] bg-opacity-10 border border-[#6FCF97] rounded-md p-3">
            <p className="text-[#27AE60] text-sm flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              {!phoneVerified && !emailVerified && "Por favor, valide seu celular e e-mail antes de continuar"}
              {!phoneVerified && emailVerified && "Por favor, valide seu número de celular antes de continuar"}
              {phoneVerified && !emailVerified && "Por favor, valide seu e-mail antes de continuar"}
            </p>
          </div>
        )}
      </div>

      <div className="flex justify-end gap-4 pt-6 border-t border-[#E0E0E0]">
        <Button
          onClick={onCancel}
          variant="outline"
          className="border-[#27AE60] text-[#27AE60] hover:bg-[#27AE60] hover:text-white"
        >
          CANCELAR
        </Button>
        <Button
          onClick={handleNext}
          disabled={!canProceed()}
          className={`${
            canProceed() 
              ? "bg-[#6FCF97] hover:bg-[#27AE60] text-white" 
              : "bg-[#F2F2F2] text-[#4F4F4F] cursor-not-allowed"
          }`}
        >
          AVANÇAR
        </Button>
      </div>
    </div>
  );
}