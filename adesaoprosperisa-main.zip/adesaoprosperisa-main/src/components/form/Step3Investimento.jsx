import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Banknote, CreditCard, AlertCircle } from "lucide-react";

export default function Step3Investimento({ formData, updateFormData, onNext, onPrev, onCancel }) {
  const [errors, setErrors] = useState({});
  const [suggestedValue, setSuggestedValue] = useState(0);
  const [displayValorObjetivo, setDisplayValorObjetivo] = useState("");
  const [displayValorMensal, setDisplayValorMensal] = useState("");

  useEffect(() => {
    // Inicializar displays com valores existentes
    if (formData.valor_objetivo > 0) {
      setDisplayValorObjetivo(formatCurrencyDisplay(formData.valor_objetivo));
    }
    if (formData.valor_mensal > 0) {
      setDisplayValorMensal(formatCurrencyDisplay(formData.valor_mensal));
    }
  }, []);

  useEffect(() => {
    if (formData.tempo_investimento_anos > 0 && formData.valor_objetivo > 0) {
      const months = formData.tempo_investimento_anos * 12;
      const monthlyRate = 0.008;
      const suggested = (formData.valor_objetivo * monthlyRate) / 
                       ((Math.pow(1 + monthlyRate, months) - 1));
      setSuggestedValue(Math.max(50, Math.round(suggested * 100) / 100));
    }
  }, [formData.tempo_investimento_anos, formData.valor_objetivo]);

  const formatCurrencyDisplay = (value) => {
    return value.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const parseCurrencyInput = (value) => {
    // Remove tudo exceto números
    const cleaned = value.replace(/\D/g, "");
    if (!cleaned) return 0;
    // Converte para número dividindo por 100 (centavos)
    return parseFloat(cleaned) / 100;
  };

  const handleCurrencyChange = (field, value) => {
    const numericValue = parseCurrencyInput(value);
    const displayValue = formatCurrencyDisplay(numericValue);
    
    if (field === "valor_objetivo") {
      setDisplayValorObjetivo(displayValue);
      updateFormData({ valor_objetivo: numericValue });
    } else if (field === "valor_mensal") {
      setDisplayValorMensal(displayValue);
      updateFormData({ valor_mensal: numericValue });
      
      // Validar valor mínimo em tempo real
      if (numericValue > 0 && numericValue < 50) {
        setErrors(prev => ({ ...prev, valor_mensal: "Valor mínimo é R$ 50,00" }));
      } else {
        setErrors(prev => ({ ...prev, valor_mensal: "" }));
      }
    }
  };

  const validateResponsavelName = (name) => {
    if (!name) return "Nome completo é obrigatório";
    if (/\d/.test(name)) return "Nome não pode conter números";
    const parts = name.trim().split(" ");
    if (parts.length < 2) return "Digite nome e sobrenome";
    
    // Verificar se é o mesmo nome do titular
    if (name.toLowerCase() === formData.nome_completo.toLowerCase()) {
      return "O responsável não pode ser o mesmo titular do plano";
    }
    
    return "";
  };

  const validateResponsavelCPF = (cpf) => {
    const cleaned = cpf.replace(/\D/g, "");
    if (cleaned.length !== 11) return "CPF deve ter 11 dígitos";
    
    // Verificar se não é o mesmo CPF do titular
    const titularCPF = formData.cpf.replace(/\D/g, "");
    if (cleaned === titularCPF) {
      return "O CPF do responsável não pode ser o mesmo do titular";
    }
    
    // Validação de CPF
    if (/^(\d)\1+$/.test(cleaned)) return "CPF inválido";
    
    let sum = 0;
    for (let i = 0; i < 9; i++) {
      sum += parseInt(cleaned.charAt(i)) * (10 - i);
    }
    let digit = 11 - (sum % 11);
    if (digit > 9) digit = 0;
    if (digit !== parseInt(cleaned.charAt(9))) return "CPF inválido";
    
    sum = 0;
    for (let i = 0; i < 10; i++) {
      sum += parseInt(cleaned.charAt(i)) * (11 - i);
    }
    digit = 11 - (sum % 11);
    if (digit > 9) digit = 0;
    if (digit !== parseInt(cleaned.charAt(10))) return "CPF inválido";
    
    return "";
  };

  const formatCPF = (value) => {
    const cleaned = value.replace(/\D/g, "");
    return cleaned
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d{1,2})/, "$1-$2")
      .replace(/(-\d{2})\d+?$/, "$1");
  };

  const handleResponsavelChange = (isResponsavel) => {
    updateFormData({ 
      responsavel_financeiro: isResponsavel,
      responsavel_nome: "",
      responsavel_cpf: ""
    });
    setErrors({});
  };

  const handleResponsavelFieldChange = (field, value) => {
    let formattedValue = value;
    
    if (field === "responsavel_cpf") {
      formattedValue = formatCPF(value);
    }
    
    updateFormData({ [field]: formattedValue });
    
    // Validação em tempo real
    let error = "";
    if (field === "responsavel_nome") error = validateResponsavelName(formattedValue);
    else if (field === "responsavel_cpf") error = validateResponsavelCPF(formattedValue);
    
    setErrors(prev => ({ ...prev, [field]: error }));
  };

  const canProceed = () => {
    const baseValidation = (
      formData.tempo_investimento_anos > 0 &&
      formData.valor_objetivo > 0 &&
      formData.valor_mensal >= 50 &&
      formData.dia_vencimento &&
      formData.forma_pagamento &&
      !errors.valor_mensal
    );

    if (!formData.responsavel_financeiro) {
      return baseValidation && 
             !validateResponsavelName(formData.responsavel_nome) &&
             !validateResponsavelCPF(formData.responsavel_cpf) &&
             formData.responsavel_nome &&
             formData.responsavel_cpf;
    }

    return baseValidation;
  };

  const handleNext = () => {
    if (!formData.responsavel_financeiro) {
      const nomeError = validateResponsavelName(formData.responsavel_nome);
      const cpfError = validateResponsavelCPF(formData.responsavel_cpf);
      
      if (nomeError || cpfError) {
        setErrors({
          ...errors,
          responsavel_nome: nomeError,
          responsavel_cpf: cpfError
        });
        return;
      }
    }

    if (canProceed()) {
      onNext();
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#27AE60] mb-2">Investimento</h2>
        <p className="text-[#4F4F4F]">Defina seu plano de acumulação</p>
      </div>

      <div className="space-y-6">
        <div>
          <Label htmlFor="tempo" className="text-[#4F4F4F] font-medium">
            Tempo de investimento *
          </Label>
          <div className="flex items-center gap-3 mt-1">
            <Input
              id="tempo"
              type="number"
              min="1"
              value={formData.tempo_investimento_anos}
              onChange={(e) => updateFormData({ tempo_investimento_anos: parseInt(e.target.value) || 1 })}
              className="w-24 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] border-[#E0E0E0]"
            />
            <span className="text-[#4F4F4F]">
              {formData.tempo_investimento_anos === 1 ? "ano" : "anos"}
            </span>
          </div>
        </div>

        <div>
          <Label htmlFor="valor_objetivo" className="text-[#4F4F4F] font-medium">
            Valor desejado a acumular (R$) *
          </Label>
          <div className="relative mt-1">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#4F4F4F]">R$</span>
            <Input
              id="valor_objetivo"
              value={displayValorObjetivo}
              onChange={(e) => handleCurrencyChange("valor_objetivo", e.target.value)}
              placeholder="0,00"
              className="pl-10 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] border-[#E0E0E0]"
            />
          </div>
        </div>

        {suggestedValue > 0 && (
          <div className="bg-[#6FCF97] bg-opacity-10 border-l-4 border-[#6FCF97] p-4 rounded">
            <p className="text-[#27AE60] font-medium">
              Para isso, sugerimos guardar R$ {suggestedValue.toFixed(2)}/mês, 
              considerando taxa de 0,80% ao mês.
            </p>
          </div>
        )}

        <div>
          <Label htmlFor="valor_mensal" className="text-[#4F4F4F] font-medium">
            Valor mensal de contribuição (R$) * <span className="text-sm font-normal">(mínimo R$ 50,00)</span>
          </Label>
          <div className="relative mt-1">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#4F4F4F]">R$</span>
            <Input
              id="valor_mensal"
              value={displayValorMensal}
              onChange={(e) => handleCurrencyChange("valor_mensal", e.target.value)}
              placeholder="0,00"
              className={`pl-10 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] ${
                errors.valor_mensal ? "border-[#EB5757]" : "border-[#E0E0E0]"
              }`}
            />
          </div>
          {errors.valor_mensal && (
            <p className="text-[#EB5757] text-sm mt-1 flex items-center gap-1">
              <AlertCircle className="w-4 h-4" />
              {errors.valor_mensal}
            </p>
          )}
        </div>

        <div>
          <Label htmlFor="vencimento" className="text-[#4F4F4F] font-medium">
            Dia de vencimento *
          </Label>
          <Select 
            value={formData.dia_vencimento.toString()} 
            onValueChange={(value) => updateFormData({ dia_vencimento: parseInt(value) })}
          >
            <SelectTrigger className="mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="5">Dia 5</SelectItem>
              <SelectItem value="10">Dia 10</SelectItem>
              <SelectItem value="15">Dia 15</SelectItem>
              <SelectItem value="20">Dia 20</SelectItem>
              <SelectItem value="25">Dia 25</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label className="text-[#4F4F4F] font-medium mb-3 block">
            Você é o responsável financeiro? *
          </Label>
          <RadioGroup
            value={formData.responsavel_financeiro ? "sim" : "nao"}
            onValueChange={(value) => handleResponsavelChange(value === "sim")}
            className="flex gap-6"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="sim" id="resp-sim" className="border-[#6FCF97] text-[#6FCF97]" />
              <Label htmlFor="resp-sim" className="cursor-pointer">Sim</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="nao" id="resp-nao" className="border-[#6FCF97] text-[#6FCF97]" />
              <Label htmlFor="resp-nao" className="cursor-pointer">Não</Label>
            </div>
          </RadioGroup>
        </div>

        {!formData.responsavel_financeiro && (
          <div className="bg-[#F2F2F2] p-6 rounded-md space-y-4 border border-[#E0E0E0]">
            <h3 className="font-semibold text-[#27AE60]">Dados do Responsável Financeiro</h3>
            
            <div>
              <Label htmlFor="resp_nome" className="text-[#4F4F4F] font-medium">
                Nome completo *
              </Label>
              <Input
                id="resp_nome"
                value={formData.responsavel_nome}
                onChange={(e) => handleResponsavelFieldChange("responsavel_nome", e.target.value)}
                placeholder="Nome completo do responsável"
                className={`mt-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] ${
                  errors.responsavel_nome ? "border-[#EB5757]" : "border-[#E0E0E0]"
                }`}
              />
              {errors.responsavel_nome && (
                <p className="text-[#EB5757] text-sm mt-1 flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" />
                  {errors.responsavel_nome}
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="resp_cpf" className="text-[#4F4F4F] font-medium">
                CPF *
              </Label>
              <Input
                id="resp_cpf"
                value={formData.responsavel_cpf}
                onChange={(e) => handleResponsavelFieldChange("responsavel_cpf", e.target.value)}
                placeholder="000.000.000-00"
                maxLength={14}
                className={`mt-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] ${
                  errors.responsavel_cpf ? "border-[#EB5757]" : "border-[#E0E0E0]"
                }`}
              />
              {errors.responsavel_cpf && (
                <p className="text-[#EB5757] text-sm mt-1 flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" />
                  {errors.responsavel_cpf}
                </p>
              )}
            </div>
          </div>
        )}

        <div>
          <Label className="text-[#4F4F4F] font-medium mb-3 block">
            Forma de pagamento *
          </Label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button
              type="button"
              onClick={() => updateFormData({ forma_pagamento: "PIX" })}
              className={`flex items-center gap-3 p-4 rounded-md border-2 transition-all ${
                formData.forma_pagamento === "PIX"
                  ? "border-[#6FCF97] bg-[#6FCF97] bg-opacity-10"
                  : "border-[#E0E0E0] hover:border-[#6FCF97]"
              }`}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                formData.forma_pagamento === "PIX" ? "bg-[#6FCF97]" : "bg-[#E0E0E0]"
              }`}>
                <Banknote className={`w-5 h-5 ${
                  formData.forma_pagamento === "PIX" ? "text-white" : "text-[#4F4F4F]"
                }`} />
              </div>
              <div className="text-left">
                <p className="font-semibold text-[#4F4F4F]">PIX</p>
                <p className="text-sm text-[#4F4F4F]">Pagamento automático</p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => updateFormData({ forma_pagamento: "Boleto" })}
              className={`flex items-center gap-3 p-4 rounded-md border-2 transition-all ${
                formData.forma_pagamento === "Boleto"
                  ? "border-[#6FCF97] bg-[#6FCF97] bg-opacity-10"
                  : "border-[#E0E0E0] hover:border-[#6FCF97]"
              }`}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                formData.forma_pagamento === "Boleto" ? "bg-[#6FCF97]" : "bg-[#E0E0E0]"
              }`}>
                <CreditCard className={`w-5 h-5 ${
                  formData.forma_pagamento === "Boleto" ? "text-white" : "text-[#4F4F4F]"
                }`} />
              </div>
              <div className="text-left">
                <p className="font-semibold text-[#4F4F4F]">Boleto</p>
                <p className="text-sm text-[#4F4F4F]">Pagamento mensal</p>
              </div>
            </button>
          </div>
        </div>
      </div>

      <div className="flex justify-between pt-6 border-t border-[#E0E0E0]">
        <div className="flex gap-4">
          <Button
            onClick={onCancel}
            variant="outline"
            className="border-[#27AE60] text-[#27AE60] hover:bg-[#27AE60] hover:text-white"
          >
            CANCELAR
          </Button>
          <Button
            onClick={onPrev}
            variant="outline"
            className="border-[#6FCF97] text-[#6FCF97] hover:bg-[#6FCF97] hover:text-white"
          >
            VOLTAR
          </Button>
        </div>
        <Button
          onClick={handleNext}
          disabled={!canProceed()}
          className={`${
            canProceed() 
              ? "bg-[#6FCF97] hover:bg-[#27AE60] text-white" 
              : "bg-[#F2F2F2] text-[#4F4F4F] cursor-not-allowed"
          }`}
        >
          AVANÇAR
        </Button>
      </div>
    </div>
  );
}