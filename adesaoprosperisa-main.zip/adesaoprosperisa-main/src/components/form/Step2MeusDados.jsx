
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertCircle, Upload, FileText, CheckCircle2, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function Step2MeusDados({ formData, updateFormData, onNext, onPrev, onCancel }) {
  const [errors, setErrors] = useState({});
  const [isLoadingCEP, setIsLoadingCEP] = useState(false);
  const [uploadingDoc, setUploadingDoc] = useState(null); // State to track which document is being uploaded
  const [uploadedDocs, setUploadedDocs] = useState({
    rg: formData.documentos?.rg_url || null,
    cin: formData.documentos?.cin_url || null,
    cnh: formData.documentos?.cnh_url || null
  });

  const formatCEP = (value) => {
    const cleaned = value.replace(/\D/g, "");
    return cleaned.replace(/(\d{5})(\d)/, "$1-$2").replace(/(-\d{3})\d+?$/, "$1");
  };

  const handleCEPChange = (value) => {
    const formatted = formatCEP(value);
    updateFormData({ 
      endereco: { ...formData.endereco, cep: formatted } 
    });
  };

  const fetchAddressByCEP = async (cep) => {
    const cleaned = cep.replace(/\D/g, "");
    if (cleaned.length !== 8) return;

    setIsLoadingCEP(true);
    setErrors(prev => ({ ...prev, cep: undefined })); // Clear previous CEP error
    try {
      const response = await fetch(`https://viacep.com.br/ws/${cleaned}/json/`);
      const data = await response.json();

      if (!data.erro) {
        updateFormData({
          endereco: {
            ...formData.endereco,
            cep: cep,
            logradouro: data.logradouro,
            bairro: data.bairro,
            municipio: data.localidade,
            uf: data.uf
          }
        });
      } else {
        setErrors(prev => ({ ...prev, cep: "CEP não encontrado" }));
      }
    } catch (error) {
      setErrors(prev => ({ ...prev, cep: "Erro ao buscar CEP" }));
    }
    setIsLoadingCEP(false);
  };

  const handleCEPBlur = () => {
    if (formData.endereco.cep && formData.endereco.cep.replace(/\D/g, "").length === 8) {
      fetchAddressByCEP(formData.endereco.cep);
    }
  };

  const handleFileUpload = async (documentType, file) => {
    if (!file) return;

    // Validar tamanho (máx 10MB)
    if (file.size > 10 * 1024 * 1024) {
      alert('O arquivo deve ter no máximo 10MB');
      return;
    }

    // Validar tipo
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    if (!validTypes.includes(file.type)) {
      alert('Apenas arquivos JPG, PNG ou PDF são permitidos');
      return;
    }

    setUploadingDoc(documentType);

    try {
      const formDataToSend = new FormData();
      formDataToSend.append('file', file);
      formDataToSend.append('documentType', documentType);
      formDataToSend.append('cpf', formData.cpf); // Assuming formData.cpf exists and is required

      const response = await base44.functions.invoke('uploadDocumentToOneDrive', formDataToSend);

      if (response.data.success) {
        const newDocs = { ...uploadedDocs, [documentType]: response.data.fileUrl };
        setUploadedDocs(newDocs);
        
        // Update parent formData
        updateFormData({
          documentos: {
            rg_url: newDocs.rg || null,
            cin_url: newDocs.cin || null,
            cnh_url: newDocs.cnh || null
          }
        });
      } else {
        alert('Erro ao fazer upload: ' + (response.data.message || 'Falha desconhecida.'));
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Erro ao fazer upload do documento');
    } finally {
      setUploadingDoc(null);
    }
  };

  const canProceed = () => {
    return (
      formData.data_nascimento &&
      formData.sexo &&
      formData.estado_civil &&
      formData.endereco.cep &&
      formData.endereco.logradouro &&
      formData.endereco.numero &&
      formData.endereco.bairro &&
      formData.endereco.municipio &&
      formData.endereco.uf
    );
  };

  const handleNext = () => {
    if (canProceed()) {
      onNext();
    }
  };

  const documentLabels = {
    rg: 'RG (Registro Geral)',
    cin: 'CIN (Carteira de Identidade Nacional)',
    cnh: 'CNH (Carteira Nacional de Habilitação)'
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-[#27AE60] mb-2">Meus dados</h2>
        <p className="text-[#4F4F4F]">Complete seu perfil pessoal</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="data_nascimento" className="text-[#4F4F4F] font-medium">
            Data de nascimento *
          </Label>
          <Input
            id="data_nascimento"
            type="date"
            value={formData.data_nascimento || ""}
            onChange={(e) => updateFormData({ data_nascimento: e.target.value })}
            className="mt-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] border-[#E0E0E0]"
          />
        </div>

        <div>
          <Label htmlFor="sexo" className="text-[#4F4F4F] font-medium">
            Sexo *
          </Label>
          <Select value={formData.sexo || ""} onValueChange={(value) => updateFormData({ sexo: value })}>
            <SelectTrigger className="mt-1">
              <SelectValue placeholder="Selecione" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Masculino">Masculino</SelectItem>
              <SelectItem value="Feminino">Feminino</SelectItem>
              <SelectItem value="Outro">Outro</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="md:col-span-2">
          <Label htmlFor="estado_civil" className="text-[#4F4F4F] font-medium">
            Estado civil *
          </Label>
          <Select value={formData.estado_civil || ""} onValueChange={(value) => updateFormData({ estado_civil: value })}>
            <SelectTrigger className="mt-1">
              <SelectValue placeholder="Selecione" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Solteiro(a)">Solteiro(a)</SelectItem>
              <SelectItem value="Casado(a)">Casado(a)</SelectItem>
              <SelectItem value="Divorciado(a)">Divorciado(a)</SelectItem>
              <SelectItem value="Viúvo(a)">Viúvo(a)</SelectItem>
              <SelectItem value="União Estável">União Estável</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Seção de Documentos */}
      <div className="border-t border-[#E0E0E0] pt-6 mt-6">
        <h3 className="text-lg font-semibold text-[#27AE60] mb-4">Documentos (Opcional)</h3>
        <p className="text-sm text-[#4F4F4F] mb-4">
          Faça upload de um dos seguintes documentos de identificação (JPG, PNG ou PDF - máx 10MB)
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {['rg', 'cin', 'cnh'].map((docType) => (
            <div key={docType} className="border-2 border-dashed border-[#E0E0E0] rounded-lg p-4 hover:border-[#6FCF97] transition-colors">
              <Label htmlFor={`upload-${docType}`} className="block text-[#4F4F4F] font-medium mb-2">
                {documentLabels[docType]}
              </Label>
              
              {uploadedDocs[docType] ? (
                <div className="flex items-center gap-2 p-3 bg-[#27AE60] bg-opacity-10 rounded-md">
                  <CheckCircle2 className="w-5 h-5 text-[#27AE60]" />
                  <span className="text-sm text-[#27AE60] font-medium">Enviado com sucesso</span>
                </div>
              ) : (
                <label 
                  htmlFor={`upload-${docType}`}
                  className="flex flex-col items-center justify-center cursor-pointer py-4"
                >
                  {uploadingDoc === docType ? (
                    <Loader2 className="w-8 h-8 text-[#6FCF97] animate-spin mb-2" />
                  ) : (
                    <Upload className="w-8 h-8 text-[#6FCF97] mb-2" />
                  )}
                  <span className="text-sm text-[#4F4F4F] text-center">
                    {uploadingDoc === docType ? 'Enviando...' : 'Clique para selecionar'}
                  </span>
                  <Input
                    id={`upload-${docType}`}
                    type="file"
                    accept="image/jpeg,image/jpg,image/png,application/pdf"
                    onChange={(e) => {
                      const file = e.target.files[0];
                      if (file) handleFileUpload(docType, file);
                    }}
                    className="hidden"
                    disabled={uploadingDoc !== null}
                  />
                </label>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="border-t border-[#E0E0E0] pt-6 mt-6">
        <h3 className="text-lg font-semibold text-[#27AE60] mb-4">Endereço</h3>
        
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="cep" className="text-[#4F4F4F] font-medium">
                CEP *
              </Label>
              <Input
                id="cep"
                value={formData.endereco.cep || ""}
                onChange={(e) => handleCEPChange(e.target.value)}
                onBlur={handleCEPBlur}
                placeholder="00000-000"
                maxLength={9}
                disabled={isLoadingCEP}
                className="mt-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] border-[#E0E0E0]"
              />
              {isLoadingCEP && <p className="text-sm text-[#6FCF97] mt-1">Buscando CEP...</p>}
              {errors.cep && (
                <p className="text-[#EB5757] text-sm mt-1 flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" />
                  {errors.cep}
                </p>
              )}
            </div>

            <div className="md:col-span-2">
              <Label htmlFor="logradouro" className="text-[#4F4F4F] font-medium">
                Logradouro *
              </Label>
              <Input
                id="logradouro"
                value={formData.endereco.logradouro || ""}
                onChange={(e) => updateFormData({ 
                  endereco: { ...formData.endereco, logradouro: e.target.value } 
                })}
                placeholder="Rua, Avenida, etc."
                className="mt-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] border-[#E0E0E0]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="numero" className="text-[#4F4F4F] font-medium">
                Número *
              </Label>
              <Input
                id="numero"
                value={formData.endereco.numero || ""}
                onChange={(e) => updateFormData({ 
                  endereco: { ...formData.endereco, numero: e.target.value } 
                })}
                placeholder="Nº"
                className="mt-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] border-[#E0E0E0]"
              />
            </div>

            <div className="md:col-span-2">
              <Label htmlFor="complemento" className="text-[#4F4F4F] font-medium">
                Complemento
              </Label>
              <Input
                id="complemento"
                value={formData.endereco.complemento || ""}
                onChange={(e) => updateFormData({ 
                  endereco: { ...formData.endereco, complemento: e.target.value } 
                })}
                placeholder="Apto, Bloco, etc."
                className="mt-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] border-[#E0E0E0]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="bairro" className="text-[#4F4F4F] font-medium">
                Bairro *
              </Label>
              <Input
                id="bairro"
                value={formData.endereco.bairro || ""}
                onChange={(e) => updateFormData({ 
                  endereco: { ...formData.endereco, bairro: e.target.value } 
                })}
                placeholder="Bairro"
                className="mt-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] border-[#E0E0E0]"
              />
            </div>

            <div>
              <Label htmlFor="municipio" className="text-[#4F4F4F] font-medium">
                Município *
              </Label>
              <Input
                id="municipio"
                value={formData.endereco.municipio || ""}
                onChange={(e) => updateFormData({ 
                  endereco: { ...formData.endereco, municipio: e.target.value } 
                })}
                placeholder="Cidade"
                className="mt-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] border-[#E0E0E0]"
              />
            </div>
          </div>

          <div className="w-full md:w-1/2">
            <Label htmlFor="uf" className="text-[#4F4F4F] font-medium">
              Estado *
            </Label>
            <Input
              id="uf"
              value={formData.endereco.uf || ""}
              onChange={(e) => updateFormData({ 
                endereco: { ...formData.endereco, uf: e.target.value.toUpperCase() } 
              })}
              placeholder="UF"
              maxLength={2}
              className="mt-1 border-b-2 border-t-0 border-x-0 rounded-none focus:border-[#6FCF97] border-[#E0E0E0]"
            />
          </div>
        </div>
      </div>

      <div className="flex justify-between pt-6 border-t border-[#E0E0E0]">
        <div className="flex gap-4">
          <Button
            onClick={onCancel}
            variant="outline"
            className="border-[#27AE60] text-[#27AE60] hover:bg-[#27AE60] hover:text-white"
          >
            CANCELAR
          </Button>
          <Button
            onClick={onPrev}
            variant="outline"
            className="border-[#6FCF97] text-[#6FCF97] hover:bg-[#6FCF97] hover:text-white"
          >
            VOLTAR
          </Button>
        </div>
        <Button
          onClick={handleNext}
          disabled={!canProceed()}
          className={`${
            canProceed() 
              ? "bg-[#6FCF97] hover:bg-[#27AE60] text-white" 
              : "bg-[#F2F2F2] text-[#4F4F4F] cursor-not-allowed"
          }`}
        >
          AVANÇAR
        </Button>
      </div>
    </div>
  );
}
