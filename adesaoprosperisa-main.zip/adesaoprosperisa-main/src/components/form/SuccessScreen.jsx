import React from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Sparkles } from "lucide-react";

export default function SuccessScreen() {
  const handleNewRegistration = () => {
    // Recarregar a página para voltar ao início
    window.location.href = window.location.pathname;
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-[#FAFAF9] to-white p-6">
      <div className="max-w-2xl w-full text-center">
        <div className="mb-8 flex justify-center">
          <div className="relative">
            <div className="w-24 h-24 bg-[#6FCF97] rounded-full flex items-center justify-center animate-pulse">
              <CheckCircle2 className="w-16 h-16 text-white" />
            </div>
            <div className="absolute -top-2 -right-2">
              <Sparkles className="w-8 h-8 text-[#BB6BD9] animate-bounce" />
            </div>
            <div className="absolute -bottom-2 -left-2">
              <Sparkles className="w-6 h-6 text-[#6FCF97] animate-bounce" style={{ animationDelay: "0.2s" }} />
            </div>
          </div>
        </div>

        <h1 className="text-4xl font-bold text-[#27AE60] mb-4">
          Cadastro concluído com sucesso!
        </h1>
        
        <p className="text-xl text-[#4F4F4F] mb-8">
          Seu cadastro no plano <span className="font-semibold text-[#27AE60]">Prosperisa+</span> foi finalizado.
          <br />
          Agora você pode construir seu sonho para o futuro.
        </p>

        <div className="bg-[#6FCF97] bg-opacity-10 border-2 border-[#6FCF97] rounded-lg p-6 mb-8">
          <p className="text-[#27AE60] font-medium mb-2">
            <strong>Próximos passos:</strong>
          </p>
          <p className="text-[#4F4F4F]">
            Em breve você receberá um e-mail com todas as informações sobre seu plano e instruções 
            para ativar o pagamento automático via {" "}
            <span className="font-semibold">PIX</span>.
          </p>
        </div>

        <Button
          onClick={handleNewRegistration}
          className="bg-[#6FCF97] hover:bg-[#27AE60] text-white text-lg px-8 py-6"
        >
          Cadastrar outro usuário
        </Button>
      </div>
    </div>
  );
}